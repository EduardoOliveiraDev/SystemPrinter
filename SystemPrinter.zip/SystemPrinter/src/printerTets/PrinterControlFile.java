package printerTets;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PrinterControlFile {

	public static void removeAllPrintJobsExcept(String ownerNameToKeep, String printerName) {
	    try {
	        // Executa o comando PowerShell para listar trabalhos de impressão
	        Process process = Runtime.getRuntime().exec("powershell -Command \"Get-PrintJob -PrinterName '" + printerName + "'\"");
	        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

	        String line;
	        boolean isHeader = true;
	        while ((line = reader.readLine()) != null) {
	            if (isHeader) {
	                // Ignora a linha de cabeçalho
	                isHeader = false;
	                continue;
	            }

	            // Processa a linha para extrair JobId, Nome do Proprietário e outros dados
	            PrintJobDetails jobDetails = extractJobDetailsFromLine(line);
	            if (jobDetails != null && !jobDetails.ownerName.equals(ownerNameToKeep)) {
	                removePrintJob(printerName, jobDetails.jobId, jobDetails.ownerName);
	            }
	        }
	        reader.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	private static PrintJobDetails extractJobDetailsFromLine(String line) {
	    // Divide a linha em partes usando espaços como delimitador
	    String[] parts = line.trim().split("\\s+", 6);

	    // Verifica se a linha possui partes suficientes
	    if (parts.length >= 6) {
	        String jobId = parts[0];
	        String ownerName = parts[1]; // Ajuste conforme a posição correta do nome do proprietário na linha
	        // Retorna um objeto com os detalhes do trabalho
	        return new PrintJobDetails(jobId, ownerName);
	    }

	    // Caso não tenha informações suficientes
	    return null;
	}

	private static void removePrintJob(String printerName, String jobId, String ownerName) {
	    try {
	        // Ajusta o comando PowerShell para remover um trabalho de impressão específico
	        String command = "powershell -Command \"Remove-PrintJob -PrinterName '" + printerName + "' -ID " + jobId + "\"";
	        Process process = Runtime.getRuntime().exec(command);

	        // Espera o comando ser executado
	        int exitCode = process.waitFor();
	        if (exitCode == 0) {
	            // Imprime o nome do proprietário do trabalho removido
	            System.out.println("Trabalho de impressão com ID " + jobId + " removido. Proprietário: " + ownerName);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	private static class PrintJobDetails {
	    String jobId;
	    String ownerName;

	    PrintJobDetails(String jobId, String ownerName) {
	        this.jobId = jobId;
	        this.ownerName = ownerName;
	    }
	}


	
}