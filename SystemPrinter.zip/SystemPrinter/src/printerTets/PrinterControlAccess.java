package printerTets;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class PrinterControlAccess {

    public static void pausePrintJobs(String printerName) {
        try {
            // Obtém a lista de IDs de trabalhos de impressão
            List<String> jobIds = getPrintJobIds(printerName);

            if (jobIds.isEmpty()) {
                System.out.println("Nenhum trabalho de impressão encontrado para a impressora " + printerName);
                return;
            }

            // Cria um comando PowerShell para pausar todos os trabalhos de impressão
            String command = "powershell -Command \"Get-PrintJob -PrinterName '" + printerName + "' | Suspend-PrintJob\"";
            Process process = Runtime.getRuntime().exec(command);

            // Espera o comando ser executado
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                System.out.println("Todos os trabalhos de impressão foram pausados com sucesso.");
            } else {
                System.err.println("Falha ao pausar os trabalhos de impressão. Código de saída: " + exitCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static List<String> getPrintJobIds(String printerName) {
        List<String> jobIds = new ArrayList<>();
        try {
            // Obtém a lista de trabalhos de impressão
            Process process = Runtime.getRuntime().exec("powershell -Command \"Get-PrintJob -PrinterName '" + printerName + "'\"");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

            String line;
            boolean isHeader = true;

            while ((line = reader.readLine()) != null) {
                if (isHeader) {
                    isHeader = false;
                    continue;
                }

                // Processa a linha para extrair o ID do trabalho
                PrintJobDetails jobDetails = extractJobDetailsFromLine(line);
                if (jobDetails != null) {
                    jobIds.add(jobDetails.jobId);
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jobIds;
    }

    private static PrintJobDetails extractJobDetailsFromLine(String line) {
        // Divide a linha em partes usando espaços como delimitador
        String[] parts = line.trim().split("\\s+", 6);

        // Verifica se a linha possui partes suficientes
        if (parts.length >= 6) {
            String jobId = parts[0];
            // Retorna um objeto com os detalhes do trabalho
            return new PrintJobDetails(jobId);
        }

        // Caso não tenha informações suficientes
        return null;
    }

    private static class PrintJobDetails {
        String jobId;

        PrintJobDetails(String jobId) {
            this.jobId = jobId;
        }
    }

    public static void main(String[] args) {
        pausePrintJobs("OneNote for Windows 10");
    }
}
