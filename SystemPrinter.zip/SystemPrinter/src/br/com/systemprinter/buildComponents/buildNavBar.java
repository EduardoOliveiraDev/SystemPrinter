package br.com.systemprinter.buildComponents;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import br.com.systemprinter.PrinterUtils.PrinterBlockedAccessNative;
import br.com.systemprinter.buildMethods.buildMethos;
import br.com.systemprinter.buildMethods.colorList;
import br.com.systemprinter.buildMethods.fontList;

public class buildNavBar {
	private static buildNavBar instance;
	
	private JPanel mainPanelNavbar;
	private JButton buttonExit;
	private JButton buttonMinimize;
	private JLabel labelTitle;
    private int mouseX;
    private int mouseY;
	
    public buildNavBar(){}
    
    public JPanel containerMain(JFrame frame, String Title, double width) {
        mainPanelNavbar = buildMethos.createPanel(new BorderLayout(), width, 2.5, colorList.colorCyanTiber, 0, 0, 0, 0);
        buttonExit = buildMethos.createJButton("X", 2.5, 2.5, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold14, colorList.colorWhiteClear, "Fechar",0, 0, 0, 0);
        buttonMinimize = buildMethos.createJButton("-", 2.5, 2.5, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold14, colorList.colorWhiteClear, "Minimizar",0, 0, 0, 0);
        
        labelTitle = buildMethos.createJLabel(Title, (width/1.5), 2, colorList.colorCyanTiber ,SwingConstants.LEFT, fontList.RobotoBold12, colorList.colorWhiteClear, "Nome do painel",0, 10, 0, 0);
        
        JPanel buttonPanel = buildMethos.createPanel(new FlowLayout(FlowLayout.RIGHT, 0,0), 7.5, 2.5, colorList.colorCyanTiber, 0, 0, 0, 0);
        buttonPanel.add(buttonMinimize);
        buttonPanel.add(buttonExit);
        
        customComponents();
        functionComponents(frame);
        movTela(frame);
        
        mainPanelNavbar.add(labelTitle, BorderLayout.WEST);
        mainPanelNavbar.add(buttonPanel, BorderLayout.EAST);
        return mainPanelNavbar;
    }	

	public void customComponents() {
		buttonExit.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				buttonExit.setBackground(colorList.colorRed);
				buttonExit.setToolTipText("Fechar");
				PrinterBlockedAccessNative.startSpooler();
			}
			
			public void mouseExited(MouseEvent e) {
				buttonExit.setBackground(colorList.colorCyanTiber);
			}
			
		});
		
		buttonMinimize.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				buttonMinimize.setBackground(colorList.colorGray);
				buttonMinimize.setToolTipText("Minimizar");
			}
			
			public void mouseExited(MouseEvent e) {
				buttonMinimize.setBackground(colorList.colorCyanTiber);
			}
			
		});
		
	}
	
	public void functionComponents(JFrame frame) {
		buttonExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		
		
		buttonMinimize.addActionListener(e -> frame.setExtendedState(JFrame.ICONIFIED));
	}
	
	public void movTela(JFrame frame) {
        frame.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });
        
        frame.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;

                frame.setLocation(x, y);
            }
        });
        
        labelTitle.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });
        
        labelTitle.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;

                frame.setLocation(x, y);
            }
        });
        
	}
	
    public static buildNavBar getInstance() {
        if (instance == null) {
            instance = new buildNavBar();
        }
        return instance;
    }
	
	
}
