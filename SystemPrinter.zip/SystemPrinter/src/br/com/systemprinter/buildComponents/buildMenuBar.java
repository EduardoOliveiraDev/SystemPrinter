package br.com.systemprinter.buildComponents;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import br.com.systemprinter.buildMethods.buildMethos;
import br.com.systemprinter.buildMethods.colorList;
import br.com.systemprinter.buildMethods.fontList;
import br.com.systemprinter.dao.UserSessionDAO;
import br.com.systemprinter.view.FrameAcessControlBrand;
import br.com.systemprinter.view.FrameControlBoard;
import br.com.systemprinter.view.FrameRecordGeneration;
import br.com.systemprinter.view.FrameUsersConfig;
import br.com.systemprinter.view.FrameUsersList;

public class buildMenuBar {
	private JMenuBar menuBar;
	private JMenuBar menuBarButtons;
	private JMenuBar menuBarLogout;
	private JMenuItem goBackAction;
	
	private JMenu buttonUsers;
	private JMenuItem userListAction;
	private JMenuItem userConfigAction;
	
	private JMenu buttonRecord;
	private JMenuItem recordGenerationAction;
	
	public JMenuBar containerMain() {
		menuBar = buildMethos.createJMenuBar(new BorderLayout(), 70, 2, colorList.colorGray);
		
		menuBarLogout();	    
	    menuBarButtons();
	    menuBar.add(menuBarButtons, BorderLayout.WEST);
		menuBar.add(menuBarLogout, BorderLayout.EAST);
	    verifyAccess();
	    return menuBar;
	}
	
	private JMenuBar menuBarButtons() {
		menuBarButtons = buildMethos.createJMenuBar(new FlowLayout(FlowLayout.LEFT, 0,0), 30, 2, colorList.colorGray);

		buttonUsers();
		buttonRecord();
		
		menuBarButtons.add(buttonUsers);
		menuBarButtons.add(buttonRecord);
		return menuBarButtons;
	}
	
	private JMenuBar menuBarLogout() {
		menuBarLogout = buildMethos.createJMenuBar(new FlowLayout(FlowLayout.LEFT, 0,0), 4, 2, colorList.colorGray);
	    goBackAction = buildMethos.createJMenuButton("Deslogar", 4, 2, colorList.colorGray, fontList.RobotoPlain12, colorList.colorWhiteClear);

	    goBackAction.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
				FrameAcessControlBrand.getInstance().getFrame().setVisible(true);
				FrameControlBoard.getInstance().getFrame().dispose();
				UserSessionDAO.getInstance().setUserSession(0, "", "", "");
	    	}
	    });
	    
	    menuBarLogout.add(goBackAction);
	    return menuBarLogout;
	}
	
	private JMenu buttonUsers() {
		buttonUsers = buildMethos.createJMenuButton("Usuarios", 4, 2, colorList.colorGray, fontList.RobotoPlain12, colorList.colorWhiteClear);
        
        userListAction = buildMethos.createJMenuItemPopUp("Lista de Usuarios", 12, 2, colorList.colorLightGray, fontList.RobotoBold12, colorList.colorBlack);
        userListAction.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, KeyEvent.CTRL_DOWN_MASK));
        userListAction.addActionListener((ActionEvent e ) -> {
        	FrameUsersList.getInstance().setVisible(true);
        });
        
        userConfigAction = buildMethos.createJMenuItemPopUp("Configurações", 12, 2, colorList.colorLightGray, fontList.RobotoBold12, colorList.colorBlack);
        userConfigAction.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U, KeyEvent.CTRL_DOWN_MASK));
        userConfigAction.addActionListener((ActionEvent e ) -> {
            FrameUsersConfig.getInstance().setVisible(true);
            
        });
        
        buttonUsers.add(userListAction);
        buttonUsers.addSeparator();
        buttonUsers.add(userConfigAction);
        
		return buttonUsers;
	}
	
	private JMenu buttonRecord() {
		buttonRecord = buildMethos.createJMenuButton("Relatorio", 4, 2, colorList.colorGray, fontList.RobotoPlain12, colorList.colorWhiteClear);
		
		recordGenerationAction = buildMethos.createJMenuItemPopUp("Gerar relatorio", 12, 2, colorList.colorLightGray, fontList.RobotoBold12, colorList.colorBlack);
		recordGenerationAction.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, KeyEvent.CTRL_DOWN_MASK));
		recordGenerationAction.addActionListener((ActionEvent e ) -> {
        	FrameRecordGeneration.getInstance().getFrame().setVisible(true);
        });
		
		buttonRecord.add(recordGenerationAction);
		return buttonRecord;
	}

	private void verifyAccess() {
		String access_level = UserSessionDAO.getInstance().getAccessLevel();
		if (access_level == null) {
			access_level = "Developer";
		}
		
		// Access Professor
		if (access_level.equalsIgnoreCase("Professor")) {
			buttonUsers.setEnabled(false);
			buttonUsers.setVisible(false);
		
			buttonRecord.setEnabled(false);
			buttonRecord.setVisible(false);
		}
		
		// Access PCA
		if (access_level.equalsIgnoreCase("PCA")) {
			userConfigAction.setEnabled(false);
			userConfigAction.setVisible(false);
			
			buttonRecord.setEnabled(false);
			buttonRecord.setVisible(false);
		}
		
		// Access PGC
		if (access_level.equalsIgnoreCase("PCG")) {
			userConfigAction.setEnabled(false);
			userConfigAction.setVisible(false);
		}
		
		
	}
}
