package br.com.systemprinter.model;

import java.sql.Timestamp;

public class PrintHistoricModel {

	private int id;
    private Timestamp  printDate;      
    private String user;       
    private String userCPF;       
    private int numberOfPages;   
    private String statusPrinter;
    
    public PrintHistoricModel() {
    	
    }
     
    public PrintHistoricModel(int id, Timestamp  printDate, String user, String userCPF, int numberOfPages, String status) {
    	this.id = id;
        this.printDate = printDate;
        this.user = user;
        this.userCPF = userCPF;
        this.numberOfPages = numberOfPages;
        this.statusPrinter = status;
    }
    
    public PrintHistoricModel(String user, String userCPF, int numberOfPages, String status) {
        this.user = user;
        this.userCPF = userCPF;
        this.numberOfPages = numberOfPages;
        this.statusPrinter = status;
    }
    
    public PrintHistoricModel(String user, String userCPF, int numberOfPages) {
        this.user = user;
        this.userCPF = userCPF;
        this.numberOfPages = numberOfPages;
    }

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}   
	
	public Timestamp  getPrintDate() {
		return printDate;
	}
	public void setPrintDate(Timestamp  printDate) {
		this.printDate = printDate;
	}
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	public String getUserCPF() {
		return userCPF;
	}
	public void setUserCPF(String userCPF) {
		this.userCPF = userCPF;
	}
	
	public int getNumberOfPages() {
		return numberOfPages;
	}
	public void setNumberOfPages(int numberOfPages) {
		this.numberOfPages = numberOfPages;
	}
	
	public String getStatus() {
		return statusPrinter;
	}
	public void setStatus(String status) {
		this.statusPrinter = status;
	}

	


 
	
}
