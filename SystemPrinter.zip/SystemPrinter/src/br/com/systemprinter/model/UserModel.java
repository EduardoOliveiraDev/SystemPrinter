package br.com.systemprinter.model;

public class UserModel {

	private int id;
	private String CPF;
	private String username;
	private String password;
	private String level;
	
    public UserModel(int id, String CPF, String username, String password, String level) {
        this.id = id;
        this.CPF = CPF;
        this.username = username;
        this.password = password;
        this.level = level;
    }
    
    public UserModel(int id, String password) {
        this.id = id;
        this.password = password;
    }
    
    public UserModel(String level, int id) {
    	this.id = id;
    	this.level = level;
    }
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String CPF) {
		this.CPF = CPF;
	}
	public String getUser() {
		return username;
	}
	public void setUser(String user) {
		this.username = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	

	
}
