package br.com.systemprinter.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.systemprinter.jdbc.connectSQL;
import br.com.systemprinter.model.UserModel;
import br.com.systemprinter.utils.EncryptionUtils;

public class UserDAO{
    private Connection connection;

    public UserDAO() {
        this.connection = new connectSQL().getConnect();
    }

    public void createUser(UserModel userInfo) throws Exception {
        
        try (PreparedStatement stmt = connection.prepareStatement("INSERT INTO users_login_table (access_cpf, access_username, access_password, access_level) VALUES (?, ?, ?, ?)")) {
        	stmt.setString(1, userInfo.getCPF());
            stmt.setString(2, userInfo.getUser());
            stmt.setString(3, EncryptionUtils.encrypt(userInfo.getPassword()));
            stmt.setString(4, userInfo.getLevel());
            
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); 
            JOptionPane.showMessageDialog(null, "Erro ao criar usuário: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            throw e; 
        }
    }
    
    public void changeUsersInformation(UserModel userInfo) throws Exception {
        StringBuilder sql = new StringBuilder("UPDATE users_login_table SET ");
        List<Object> params = new ArrayList<>();

        if (userInfo.getCPF() != null && !userInfo.getCPF().isEmpty()) {
            sql.append("access_cpf = ?, ");
            params.add(userInfo.getCPF());
        }
        
        if (userInfo.getUser() != null && !userInfo.getUser().isEmpty()) {
            sql.append("access_username = ?, ");
            params.add(userInfo.getUser());
        }

        if (userInfo.getPassword() != null && !userInfo.getPassword().isEmpty()) {
            sql.append("access_password = ?, ");
            params.add(EncryptionUtils.encrypt(userInfo.getPassword()));
        }

        if (userInfo.getLevel() != null && !userInfo.getLevel().isEmpty()) {
            sql.append("access_level = ?, ");
            params.add(userInfo.getLevel());
        }

        sql.setLength(sql.length() - 2);
        sql.append(" WHERE access_id = ?");

        params.add(userInfo.getId());

        try (PreparedStatement stmt = connection.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }
            stmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao editar o item");
        }
    }

    public List<UserModel> listingDatabaseTableUsers() throws SQLException {
        List<UserModel> list = new ArrayList<>();
        PreparedStatement stmt = connection.prepareStatement
        		("SELECT * FROM users_login_table");

        ResultSet rs = stmt.executeQuery();
        try {
            while (rs.next()) {
                UserModel obj = new UserModel(
                		rs.getInt("access_id"), 
                		rs.getString("access_cpf"), 
                		rs.getString("access_username"), 
                		rs.getString("access_password"), 
                		rs.getString("access_level"));

                list.add(obj);
            }
            return list;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao criar a lista: " + e.getMessage());
        } finally {
            rs.close();
            stmt.close();
        }

        return list;
    }

    public boolean isValidUser(String CPF, String password, List<String> blockedAccessLevels) {
        try (PreparedStatement stmt = connection.prepareStatement
        		("SELECT access_username, access_cpf, access_password, access_level, access_id FROM users_login_table WHERE BINARY access_cpf = ?")) {
        	
            stmt.setString(1, CPF);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                	
                    String accessLevel = rs.getString("access_level");
                    String decryptedPassword = EncryptionUtils.decrypt(rs.getString("access_password"));

                    if (decryptedPassword.equals(password)) {
                        if (blockedAccessLevels.contains(accessLevel)) {
                        	
                            JOptionPane.showMessageDialog(null, "Acesso negado! \n"
                            		+ "Seu nivel de acesso é: " + accessLevel, "Nivel de acesso insuficiente.", JOptionPane.ERROR_MESSAGE);
                            return false;
                        } else {
                            int idUser = rs.getInt("access_id");
                            String accessUser = rs.getString("access_username");
                            UserSessionDAO.getInstance().setUserSession(idUser, CPF, accessUser, accessLevel);
                            return true;
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return false;
    }

    public String getPassword(UserModel userInfo) throws Exception {
    	PreparedStatement stmt = connection.prepareStatement
    			("SELECT access_password FROM users_login_table WHERE access_id = ?");
    	
    	try {
			stmt.setInt(1, userInfo.getId());
			
			try(ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return EncryptionUtils.decrypt(rs.getString("access_password"));
				} else {
					JOptionPane.showMessageDialog(null, "Usuario não encontrado", "Erro", JOptionPane.ERROR_MESSAGE);
					return null;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    	
    }

    public List<String> getUsersByDateRange(java.util.Date startDate, java.util.Date endDate) throws SQLException {
        List<String> users = new ArrayList<>();
        String query = "SELECT DISTINCT username FROM print_historic_table WHERE print_date BETWEEN ? AND ?";

        try (PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setTimestamp(1, new java.sql.Timestamp(startDate.getTime()));
            statement.setTimestamp(2, new java.sql.Timestamp(endDate.getTime()));
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    users.add(resultSet.getString("username"));
                }
            }
        }
        return users;
    }

    public String getCPFByUserName(String userName) throws SQLException {
        String cpf = null;
        String sql = "SELECT user_cpf FROM print_historic_table WHERE username = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            
            pstmt.setString(1, userName);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    cpf = rs.getString("user_cpf");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Erro ao buscar o CPF do usuário.", e);
        }
        
        return cpf;
    }
}


