package br.com.systemprinter.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.systemprinter.jdbc.connectSQL;
import br.com.systemprinter.model.PrintHistoricModel;

public class PrintHistoricDAO {
	private Connection connection;
	
	public PrintHistoricDAO() {
		this.connection = new connectSQL().getConnect();
	}
	
	public void createPrintHistoric(PrintHistoricModel model) throws SQLException {
		PreparedStatement stmt = connection.prepareStatement
				("INSERT INTO print_historic_table (username, user_cpf, number_of_pages, status) VALUES (?,?,?,?)");
		
		try {
			stmt.setString(1, model.getUser());
			stmt.setString(2, model.getUserCPF());
			stmt.setInt(3, model.getNumberOfPages());
			stmt.setString(4, model.getStatus());
			stmt.executeUpdate();
		} catch (Exception e) {
            e.printStackTrace(); 
            JOptionPane.showMessageDialog(null, "Erro ao salvar impressão no historico" + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            throw e; 
		}
	}

	public List<PrintHistoricModel> listingPrintHistoric(int offset, int limit) throws SQLException {
	    PreparedStatement stmt = connection.prepareStatement
	    		("SELECT * FROM print_historic_table LIMIT ? OFFSET ?");
	    
	    stmt.setInt(1, limit);  
	    stmt.setInt(2, offset); 
	    
	    List<PrintHistoricModel> list = new ArrayList<>();
	    ResultSet rs = stmt.executeQuery();

	    try {
	        while (rs.next()) {
	            Timestamp printDate = rs.getTimestamp("print_date");
	            PrintHistoricModel obj = new PrintHistoricModel(
	                rs.getInt("id"),
	                printDate,   
	                rs.getString("username"),
	                rs.getString("user_cpf"),
	                rs.getInt("number_of_pages"),
	                rs.getString("status")
	            );
	            list.add(obj); 
	        }
	        return list;
	    } catch (SQLException e) {
	        JOptionPane.showMessageDialog(null, "Erro ao criar a lista: " + e.getMessage());
	        e.printStackTrace();
	        return list; 
	    } finally {
	        rs.close();
	        stmt.close();
	    }
	}
	
	// Excel 
    public List<List<Object>> getReportData(java.util.Date startDate, java.util.Date endDate) throws SQLException {
        List<List<Object>> data = new ArrayList<>();
        
        String query = "SELECT * FROM print_historic_table WHERE print_date BETWEEN ? AND ?";
        
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            
            preparedStatement.setDate(1, new java.sql.Date(startDate.getTime()));
            preparedStatement.setDate(2, new java.sql.Date(endDate.getTime()));
            
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                ResultSetMetaData metaData = resultSet.getMetaData();
                int columnCount = metaData.getColumnCount();
                
                List<Object> headers = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    headers.add(metaData.getColumnName(i));
                }
                data.add(headers);
                
                while (resultSet.next()) {
                    List<Object> row = new ArrayList<>();
                    for (int i = 1; i <= columnCount; i++) {
                        row.add(resultSet.getObject(i));
                    }
                    data.add(row);
                }
            }
        }
        return data;
    }

    // PDF
    public List<PrintHistoricModel> getUserReportData(java.util.Date startDate, java.util.Date endDate, String CPF) throws SQLException {
        List<PrintHistoricModel> userReportDataList = new ArrayList<>();

        // Verifique se CPF é null e trate o caso
        if (CPF == null) {
            CPF = "TODOS";
        }

        // Ajuste na consulta SQL
        String sql = "SELECT username, user_cpf, SUM(number_of_pages) AS total_pages "
                + "FROM print_historic_table "
                + "WHERE print_date BETWEEN ? AND ? "
                + (CPF.equals("TODOS") ? "" : "AND user_cpf = ? ")  // Adiciona condição apenas se CPF não for 'TODOS'
                + "GROUP BY username, user_cpf";


        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, new java.sql.Date(startDate.getTime()));
            stmt.setDate(2, new java.sql.Date(endDate.getTime()));

            if (!CPF.equals("TODOS")) {
                stmt.setString(3, CPF);  // Adiciona parâmetro CPF se necessário
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String username = rs.getString("username");
                    String userCPF = rs.getString("user_cpf");
                    int totalPages = rs.getInt("total_pages");

                    userReportDataList.add(new PrintHistoricModel(username, userCPF, totalPages));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }

        return userReportDataList;
    }

}
