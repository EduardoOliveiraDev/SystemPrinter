package br.com.systemprinter.dao;

public class UserSessionDAO {
	private static UserSessionDAO instance;
	private int accessidUser;
	private String currentCPF;
	private String currentUser;
	private String accessLevel;

	public static synchronized UserSessionDAO getInstance() {
		if (instance == null) {
			instance = new UserSessionDAO();
		}
		return instance;
	}

	public void setUserSession(int idUser, String CPF, String user, String accessLevel) {
		this.accessidUser = idUser;
		this.currentCPF = CPF;
		this.currentUser = user;
		this.accessLevel = accessLevel;
	}

	public int getAccessIdUser() {
		return accessidUser;
	}

	public String getAccessCPF() {
		return currentCPF;
	}
	
	public String getCurrentUser() {
		return currentUser;
	}

	public String getAccessLevel() {
		return accessLevel;
	}

}
