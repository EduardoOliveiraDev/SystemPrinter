package br.com.systemprinter.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class connectSQL {
    final private String JDBC_url = "jdbc:mysql://localhost/system_printer";
    final private String JDBC_user = "root";
    final private String JDBC_password = "";
    
    public Connection getConnect() {
        try {
            Connection conn = DriverManager.getConnection(JDBC_url, JDBC_user, JDBC_password);
            return conn;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Falha ao se conectar ao banco de dados.", "Erro de conexão", JOptionPane.ERROR_MESSAGE);
            System.exit(1); // Exit the application on failure
        }
        return null;
    }
}