package br.com.systemprinter.jdbc;

import javax.swing.JOptionPane;

import br.com.systemprinter.view.FrameAcessControlBrand;

public class testConnection {

    public static void main(String[] args) {
        try {
            new connectSQL().getConnect();
            FrameAcessControlBrand frame = new FrameAcessControlBrand();
            frame.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Falha ao se conectar ao banco de dados.", "Erro de conexão", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}