package br.com.systemprinter.utils;

import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionUtils {

    private static final String ALGORITHM = "AES";
    private static final String KEY = "4f7ad3921e3f9b64a06d2f558b0c1a7e";

    private static byte[] generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return salt;
    }

    public static String encrypt(String data) throws Exception {
        byte[] salt = generateSalt();
        SecretKeySpec keySpec = new SecretKeySpec(KEY.getBytes(), ALGORITHM);
        Cipher cipher = Cipher.getInstance(ALGORITHM);

        String dataWithSalt = Base64.getEncoder().encodeToString(salt) + ":" + data;
        
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
        byte[] encryptedData = cipher.doFinal(dataWithSalt.getBytes());

        return Base64.getEncoder().encodeToString(salt) + ":" + Base64.getEncoder().encodeToString(encryptedData);
    }

    @SuppressWarnings("unused")
	public static String decrypt(String encryptedData) throws Exception {
        String[] parts = encryptedData.split(":");
        byte[] salt = Base64.getDecoder().decode(parts[0]);
        byte[] encryptedBytes = Base64.getDecoder().decode(parts[1]);

        SecretKeySpec keySpec = new SecretKeySpec(KEY.getBytes(), ALGORITHM);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, keySpec);
        byte[] decryptedDataWithSalt = cipher.doFinal(encryptedBytes);

        String decryptedData = new String(decryptedDataWithSalt);
        return decryptedData.split(":")[1];
    }
}