package br.com.systemprinter.utils;


import javax.print.event.PrintJobEvent;
import javax.print.event.PrintJobListener;

public class MyPrintJobListener implements PrintJobListener {

    @Override
    public void printDataTransferCompleted(PrintJobEvent e) {
        System.out.println("Print data transfer completed.");
    }

    @Override
    public void printJobCanceled(PrintJobEvent e) {
        System.out.println("Print job canceled.");
    }

    @Override
    public void printJobCompleted(PrintJobEvent e) {
        System.out.println("Print job completed.");
    }

    @Override
    public void printJobFailed(PrintJobEvent e) {
        System.out.println("Print job failed.");
    }

    @Override
    public void printJobNoMoreEvents(PrintJobEvent e) {
        System.out.println("No more print job events.");
    }

    @Override
    public void printJobRequiresAttention(PrintJobEvent e) {
        System.out.println("Print job requires attention.");
    }
}
