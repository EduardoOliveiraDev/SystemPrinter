package br.com.systemprinter.utils;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ReportServiceUtils {

    private static final String BASE_FOLDER = System.getProperty("user.home") + File.separator + "Desktop" + File.separator + "Controle de impressão";

    private static String extractCPF(String fullNameCpf) {
	    if (fullNameCpf.contains(" - ")) {
	        String[] parts = fullNameCpf.split(" - ");
	        return parts[1]; 
	    }
	    return fullNameCpf; 
	}
	
	private static String extractName(String fullNameCpf) {
	    if (fullNameCpf.contains(" - ")) {
	        String[] parts = fullNameCpf.split(" - ");
	        return parts[0]; 
	    }
	    return fullNameCpf; 
	}
    
    public static void generatePDFReport(java.sql.Timestamp startDate, java.sql.Timestamp endDate, String user, double price) {
        SimpleDateFormat fileDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String dateStr = fileDateFormat.format(new Date());
        File pdfFolder = new File(BASE_FOLDER, "pdf");
        
        String usuario = extractName(user);
        if (usuario.equalsIgnoreCase("Todos")) {
        	usuario = "All";
		}
        File pdfFile = new File(pdfFolder, usuario + "-Record-Result-" + dateStr + ".pdf");

        user = extractCPF(user);
        
        try {
            Files.createDirectories(Paths.get(BASE_FOLDER));
            Files.createDirectories(Paths.get(pdfFolder.getPath()));

            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(pdfFile));
            document.open();

            DesignRecord.addContentToPDF(document, startDate, endDate, user, price);

            document.close();

            int option = JOptionPane.showOptionDialog(
                null,
                "Relatório PDF gerado com sucesso! Está salvo na pasta 'pdf' na área de trabalho.",
                "Sucesso",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new Object[]{"Abrir", "Fechar"},
                "Fechar"
            );

            if (option == JOptionPane.YES_OPTION) {
                Desktop.getDesktop().open(pdfFolder);
            }
        } catch (IOException | com.itextpdf.text.DocumentException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao gerar o relatório PDF.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void generateExcelReport(java.sql.Timestamp startDate, java.sql.Timestamp endDate) {
        SimpleDateFormat fileDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String dateStr = fileDateFormat.format(new Date());
        File excelFolder = new File(BASE_FOLDER, "excel");
        File excelFile = new File(excelFolder, "Record-Result-" + dateStr + ".xlsx");

        try {
            Files.createDirectories(Paths.get(BASE_FOLDER));
            Files.createDirectories(Paths.get(excelFolder.getPath()));

            try (Workbook workbook = new XSSFWorkbook()) {
                DesignRecord.addContentToExcel(workbook, startDate, endDate);

                try (FileOutputStream fileOut = new FileOutputStream(excelFile)) {
                    workbook.write(fileOut);
                }
            }

            int option = JOptionPane.showOptionDialog(
                null,
                "Relatório Excel gerado com sucesso! Está salvo na pasta 'excel' na área de trabalho.",
                "Sucesso",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new Object[]{"Abrir", "Fechar"},
                "Fechar"
            );

            if (option == JOptionPane.YES_OPTION) {
                Desktop.getDesktop().open(excelFolder);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao gerar o relatório Excel.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
