package br.com.systemprinter.utils;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;

import br.com.systemprinter.dao.PrintHistoricDAO;
import br.com.systemprinter.model.PrintHistoricModel;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Collections;

public class DesignRecord {

	public static void addContentToPDF(Document document, Date startDate, Date endDate, String CPF, double price) throws DocumentException {
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String headerText = "Relatório de " + sdf.format(startDate) + " a " + sdf.format(endDate);
	    
	    document.add(new Paragraph(headerText));

	    PdfPTable table = new PdfPTable(4); // 4 colunas agora, sem a coluna de status
	    table.setWidthPercentage(100);
	    table.setSpacingBefore(10f);
	    table.setSpacingAfter(10f);

	    // Adiciona o cabeçalho das colunas
	    table.addCell("CPF");
	    table.addCell("Usuário");
	    table.addCell("Número de Páginas");
	    table.addCell("Custo Total");

	    List<PrintHistoricModel> userReportDataList = fetchUserReportData(startDate, endDate, CPF);

	    for (PrintHistoricModel data : userReportDataList) {
	        double totalCost = data.getNumberOfPages() * price; // Calcula o custo total
	        table.addCell(data.getUserCPF()); // Supondo que PrintHistoricModel tenha um método getCpf()
	        table.addCell(data.getUser());
	        table.addCell(String.valueOf(data.getNumberOfPages()));
	        table.addCell(String.format("%.2f", totalCost)); // Exibe o custo total formatado
	    }

	    document.add(table);

	    String footerText = "Gerado em: " + sdf.format(new Date());
	    document.add(new Paragraph(footerText));
	}
	
	private static List<PrintHistoricModel> fetchUserReportData(Date startDate, Date endDate, String CPF) {
	    try {
	        PrintHistoricDAO dao = new PrintHistoricDAO();
	        List<PrintHistoricModel> data = dao.getUserReportData(startDate, endDate, CPF);
	        
	        return data;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return Collections.emptyList(); // Retorna lista vazia em caso de erro
	    }
	}

    /*
     * Generation record excel table 
    */
    private static final Map<String, String> columnRenames = createColumnRenameMap();

    public static void addContentToExcel(Workbook workbook, Date startDate, Date endDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Sheet sheet = workbook.createSheet("Relatório");

        // Cria o estilo para data
        CellStyle dateCellStyle = createDateCellStyle(workbook);

        // Obtenha todos os dados para o intervalo de datas
        List<List<Object>> data = fetchData(startDate, endDate);

        if (!data.isEmpty()) {
            createTable(sheet, data, dateCellStyle);
        }

        // Adiciona uma linha de rodapé
        createFooterRow(sheet, sdf);
    }

    private static List<List<Object>> fetchData(Date startDate, Date endDate) {
        try {
            PrintHistoricDAO dao = new PrintHistoricDAO();
            return dao.getReportData(startDate, endDate);
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList(); // Retorna lista vazia em caso de erro
        }
    }

    private static void createTable(Sheet sheet, List<List<Object>> data, CellStyle dateCellStyle) {
        if (data.isEmpty()) return;

        // Criar a linha do cabeçalho
        Row tableHeaderRow = sheet.createRow(0);
        List<Object> headers = data.get(0);
        for (int i = 0; i < headers.size(); i++) {
            String originalHeader = headers.get(i).toString();
            String renamedHeader = renameColumn(originalHeader);
            tableHeaderRow.createCell(i).setCellValue(renamedHeader);
        }

        // Adicionar dados
        int rowIndex = 1; // Começar na linha 1, já que a linha 0 é para os cabeçalhos
        for (int i = 1; i < data.size(); i++) {
            Row dataRow = sheet.createRow(rowIndex++);
            List<Object> row = data.get(i);
            for (int j = 0; j < row.size(); j++) {
                Object cellValue = row.get(j);
                Cell cell = dataRow.createCell(j);

                if (cellValue instanceof Date) {
                    cell.setCellValue((Date) cellValue);
                    cell.setCellStyle(dateCellStyle);
                } else {
                    cell.setCellValue(cellValue.toString());
                }
            }
        }
    }

    private static CellStyle createDateCellStyle(Workbook workbook) {
        CellStyle dateCellStyle = workbook.createCellStyle();
        CreationHelper createHelper = workbook.getCreationHelper();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy-MM-dd HH:mm:ss"));
        return dateCellStyle;
    }

    private static String renameColumn(String columnName) {
        return columnRenames.getOrDefault(columnName, columnName);
    }

    private static Map<String, String> createColumnRenameMap() {
        Map<String, String> map = new HashMap<>();
        map.put("id", "ID");
        map.put("print_date", "Data");
        map.put("username", "Usuário");
        map.put("number_of_pages", "Páginas");
        map.put("total_cost", "Custo");
        return map;
    }

    private static void createFooterRow(Sheet sheet, SimpleDateFormat sdf) {
        int lastRowNum = sheet.getLastRowNum();
        Row footerRow = sheet.createRow(lastRowNum + 1);
        footerRow.createCell(0).setCellValue("Gerado em: " + sdf.format(new Date()));
    }
}
