package br.com.systemprinter.PrinterUtils;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import javax.print.*;
import javax.print.attribute.*;
import javax.print.attribute.standard.*;
import javax.print.event.PrintJobAdapter;
import javax.print.event.PrintJobEvent;

import java.awt.*;
import java.awt.print.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class PrinterInput {

    // Método principal para imprimir um arquivo
    public static void printFile(String filePath, String printerName, int numberOfCopies, String paperSize,  OrientationRequested orientation) {
        File file = new File(filePath);
        PrintService printService = findPrintService(printerName);
        if (printService == null) {
            System.err.println("Impressora não encontrada: " + printerName);
            return;
        }

        PrintRequestAttributeSet attributes = new HashPrintRequestAttributeSet();
        attributes.add(new Copies(numberOfCopies));
        attributes.add(getMediaSize(paperSize)); // Ajuste para o tamanho do papel desejado

        if (file.getName().endsWith(".png") || file.getName().endsWith(".jpg") || file.getName().endsWith(".jpeg")) {
            printImage(file, printService, attributes, numberOfCopies, printerName, orientation);
        } else if (file.getName().endsWith(".pdf")) {
            printPDF(file, printService, attributes, numberOfCopies, printerName, orientation);
        } else {
            System.err.println("Tipo de arquivo não suportado para impressão.");
        }
    }

    private static PrintService findPrintService(String printerName) {
        PrintService[] services = PrintServiceLookup.lookupPrintServices(null, null);
        for (PrintService service : services) {
            if (service.getName().equalsIgnoreCase(printerName)) {
                return service;
            }
        }
        return null;
    }

    private static void printImage(File file, PrintService printService, PrintRequestAttributeSet attributes, int numberOfCopies, String printerName,  OrientationRequested orientation) {
        try {
            BufferedImage image = ImageIO.read(file);
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setPrintService(printService);

            job.setPrintable((graphics, pageFormat, pageIndex) -> {
                if (pageIndex >= numberOfCopies) {
                    return Printable.NO_SUCH_PAGE;
                }

                // Ajusta a orientação do PageFormat
                if (orientation == OrientationRequested.LANDSCAPE) {
                    pageFormat.setOrientation(PageFormat.LANDSCAPE);
                } else {
                    pageFormat.setOrientation(PageFormat.PORTRAIT);
                }
                
                Graphics2D g2d = (Graphics2D) graphics;
                g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
                g2d.drawImage(image, 0, 0, (int) pageFormat.getImageableWidth(), (int) pageFormat.getImageableHeight(), null);
                return Printable.PAGE_EXISTS;
            });

            // Imprime o trabalho
            job.print(attributes);

            // Inicia uma nova thread para verificar a fila de impressão
            new Thread(() -> {
                try {
                	PrinterGetStatus.getTotalPages(numberOfCopies);
                	getStatusFilePrinter(printerName);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt(); // Restores interrupted status
                }
            }).start();

        } catch (IOException | PrinterException e) {
            System.err.println("Erro ao imprimir a imagem: " + e.getMessage());
        }
    }

    private static void printPDF(File file, PrintService printService, PrintRequestAttributeSet attributes, int numberOfCopies, String printerName, OrientationRequested orientation) {
        try (PDDocument document = PDDocument.load(file)) {
            PDFRenderer pdfRenderer = new PDFRenderer(document);
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setPrintService(printService);

            // Adiciona a orientação ao PrintRequestAttributeSet
            attributes.add(orientation);

            // Configura o PageFormat com a orientação correta
            PageFormat pageFormat = job.defaultPage();
            if (orientation == OrientationRequested.LANDSCAPE) {
                pageFormat.setOrientation(PageFormat.LANDSCAPE);
            } else {
                pageFormat.setOrientation(PageFormat.PORTRAIT);
            }

            job.setPrintable((graphics, pageFormat1, pageIndex) -> {
                int totalPages = document.getNumberOfPages();
                int effectivePageIndex = pageIndex % totalPages;

                if (pageIndex >= totalPages * numberOfCopies) {
                    return Printable.NO_SUCH_PAGE;
                }

                try {
                    BufferedImage bufferedImage = pdfRenderer.renderImageWithDPI(effectivePageIndex, 300);
                    Graphics2D g2d = (Graphics2D) graphics;
                    g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
                    g2d.drawImage(bufferedImage, 0, 0, (int) pageFormat.getImageableWidth(), (int) pageFormat.getImageableHeight(), null);
                    return Printable.PAGE_EXISTS;
                } catch (IOException e) {
                    e.printStackTrace();
                    return Printable.NO_SUCH_PAGE;
                }
            }, pageFormat); // Passa o pageFormat configurado

            // Imprime o trabalho com os atributos, incluindo a orientação
            job.print(attributes);
            
            // Inicia uma nova thread para verificar a fila de impressão
            new Thread(() -> {
                try {
                	PrinterGetStatus.getTotalPages(document.getNumberOfPages() * numberOfCopies);
                	getStatusFilePrinter(printerName);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt(); // Restores interrupted status
                }
            }).start();

        } catch (Exception e) {
            System.err.println("Erro ao imprimir o PDF: " + e.getMessage());
        }
    }

    private static void getStatusFilePrinter(String printerName) throws InterruptedException {
    	PrinterGetStatus.verifyQueuePrinter(printerName);
    	System.out.println("Parametros passados");

    }
    
    private static MediaSizeName getMediaSize(String paperSize) {
        switch (paperSize.toUpperCase()) {
            case "A4":
                return MediaSizeName.ISO_A4;
            case "LETTER":
                return MediaSizeName.NA_LETTER;
            default:
                return MediaSizeName.ISO_A4; // Padrão A4
        }
    }
}
