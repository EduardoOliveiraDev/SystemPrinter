package br.com.systemprinter.PrinterUtils;

import java.awt.*;
import java.awt.image.BufferedImage;

public class ConfigFile {

    private static final double MARGIN_CM = 0.5;
    private static final double A4_WIDTH_MM = 210; // Tamanho da folha A4 em mm
    private static final double A4_HEIGHT_MM = 297; // Tamanho da folha A4 em mm
    private static final double DPI = 72; // Resolução em DPI

    public static BufferedImage processImage(BufferedImage image) {
        // Conversão de margem de cm para pixels
        double margin = MARGIN_CM * DPI / 2.54;

        // Tamanhos da folha A4 em pixels
        int a4Width = (int) (A4_WIDTH_MM / 25.4 * DPI);
        int a4Height = (int) (A4_HEIGHT_MM / 25.4 * DPI);

        // Verifica a orientação da imagem
        boolean isPortrait = image.getHeight() > image.getWidth();

        // Calcula as dimensões da imagem final com margens
        int finalWidth, finalHeight;
        if (isPortrait) {
            finalWidth = a4Width - (int) (2 * margin);
            finalHeight = (int) ((double) finalWidth / image.getWidth() * image.getHeight());
        } else {
            finalHeight = a4Height - (int) (2 * margin);
            finalWidth = (int) ((double) finalHeight / image.getHeight() * image.getWidth());
        }

        // Ajusta a imagem se necessário
        BufferedImage resizedImage = new BufferedImage(finalWidth, finalHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2dResized = resizedImage.createGraphics();
        g2dResized.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2dResized.drawImage(image, 0, 0, finalWidth, finalHeight, null);
        g2dResized.dispose();

        // Cria uma nova imagem com fundo branco e aplica a imagem redimensionada
        BufferedImage finalImage = new BufferedImage(a4Width, a4Height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = finalImage.createGraphics();
        g2d.setColor(Color.WHITE); // Define a cor do fundo
        g2d.fillRect(0, 0, a4Width, a4Height); // Preenche o fundo com branco

        int x, y;

        if (isPortrait) {
            // Centraliza a imagem na página
            x = (a4Width - finalWidth) / 2;
            y = (a4Height - finalHeight) / 2;
            g2d.drawImage(resizedImage, x, y, null);
        } else {
            // Gira a imagem se estiver em paisagem
            BufferedImage rotatedImage = new BufferedImage(resizedImage.getHeight(), resizedImage.getWidth(), BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2dRotated = rotatedImage.createGraphics();
            g2dRotated.rotate(Math.toRadians(90), resizedImage.getHeight() / 2, resizedImage.getWidth() / 2);
            g2dRotated.drawImage(resizedImage, 0, 0, null);
            g2dRotated.dispose();

            int rotatedWidth = rotatedImage.getWidth();
            int rotatedHeight = rotatedImage.getHeight();
            x = (a4Width - rotatedWidth) / 2;
            y = (a4Height - rotatedHeight) / 2;
            g2d.drawImage(rotatedImage, x, y, null);
        }

        g2d.dispose();
        return finalImage;
    }
}
