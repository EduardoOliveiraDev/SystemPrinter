package br.com.systemprinter.PrinterUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;
import javax.swing.JOptionPane;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.systemprinter.buildFrame.buildControlBoard;
import br.com.systemprinter.dao.PrintHistoricDAO;
import br.com.systemprinter.dao.UserSessionDAO;
import br.com.systemprinter.model.PrintHistoricModel;

public class PrinterGetStatus {
    private static int totalPages;
    private static long totalDuration; // Variável para armazenar a duração total

    public static int getTotalPages(int pages) {
        return totalPages = pages;
    }

    private static String executarComandoPowershell(String printerName) throws Exception {
        String comandoPowershell = String.format(
            "powershell.exe -Command \"Get-PrintJob -PrinterName '%s' | Select-Object Id, DocumentName, JobStatus, Status, ErrorCode, PagesPrinted, TotalPages | ConvertTo-Json\"",
            printerName
        );

        ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", comandoPowershell);
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();

        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            output.append(line).append("\n");
        }

        process.waitFor();
        return output.toString();
    }

    private static void pauseFile(String printerName, int jobId) throws Exception {
        String comandoPowershell = String.format(
            "powershell.exe -Command \"Suspend-PrintJob -PrinterName '%s' -Id %d\"",
            printerName, jobId
        );

        ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", comandoPowershell);
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();

        process.waitFor();
    }

    private static void returnFileInQueue(String printerName, int jobId) throws Exception {
        String comandoPowershell = String.format(
            "powershell.exe -Command \"Resume-PrintJob -PrinterName '%s' -Id %d\"",
            printerName, jobId
        );

        ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", comandoPowershell);
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();

        process.waitFor();
    }

    public static long verifyQueuePrinter(String printName) {
        long startTime = System.nanoTime(); // Marca o tempo de início

        while (true) {
            try {
                String jsonOutput = executarComandoPowershell(printName);

                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode rootNode = objectMapper.readTree(jsonOutput);

                if (rootNode.isArray() && rootNode.size() > 0) {
                    JsonNode jobNode = rootNode.get(0); // Assumindo que há apenas um trabalho na fila

                    String status = jobNode.get("JobStatus").asText();
                    int jobId = jobNode.get("Id").asInt();

                    switch (status) {
                        case "Erro":
                            JOptionPane.showMessageDialog(null, "Aconteceu um erro durante a impressão.", "Erro de Impressão", JOptionPane.INFORMATION_MESSAGE);
                            break;

                        case "Sem Papel":
                            try {
                                pauseFile(printName, jobId);
                                JOptionPane.showMessageDialog(null, "A impressora está sem papel. Por favor, adicione papel e clique em OK para continuar a impressão.", "Erro de Impressão", JOptionPane.INFORMATION_MESSAGE);
                                returnFileInQueue(printName, jobId);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            break;

                        case "Atolamento de Papel":
                            try {
                                pauseFile(printName, jobId);
                                JOptionPane.showMessageDialog(null, "O trabalho foi pausado devido a um atolamento de papel. Resolva o problema e clique em OK para retomar a impressão.", "Atolamento de Papel", JOptionPane.INFORMATION_MESSAGE);
                                returnFileInQueue(printName, jobId);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            break;

                        case "Pouco Papel":
                            JOptionPane.showMessageDialog(null, "O papel está acabando!", "Pouco Papel", JOptionPane.WARNING_MESSAGE);
                            // Adicione lógica para salvar o arquivo com erro, se necessário
                            break;

                        case "Cancelado":
                            JOptionPane.showMessageDialog(null, "O trabalho de impressão foi cancelado. Remover da fila...", "Trabalho Cancelado", JOptionPane.INFORMATION_MESSAGE);
                            break;

                        default:
                            System.out.println("Status desconhecido: " + status);
                            break;
                    }
                } else {
                    savePrintInDataBase(printName);
                    break;
                }

                TimeUnit.SECONDS.sleep(5); 
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        long endTime = System.nanoTime(); // Marca o tempo de término
        totalDuration = endTime - startTime; // Armazena a duração total
        return totalDuration; // Retorna a duração total
    }

    private static void savePrintInDataBase(String printName) throws SQLException {
        String user = UserSessionDAO.getInstance().getCurrentUser();
        String userCPF = UserSessionDAO.getInstance().getAccessCPF();
        String status = "Concluido";
        PrintHistoricModel userModel = new PrintHistoricModel(user, userCPF, totalPages, status);

        PrintHistoricDAO dao = new PrintHistoricDAO();
        dao.createPrintHistoric(userModel);
        PrinterBlockedAccessNative.stopSpooler();
    }

    public static long getTotalDuration() {
        return totalDuration; // Método para obter a duração total
    }
}
