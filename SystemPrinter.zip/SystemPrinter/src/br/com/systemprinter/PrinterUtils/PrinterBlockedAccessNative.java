package br.com.systemprinter.PrinterUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PrinterBlockedAccessNative {

    public static void stopSpooler() {
        String command = "Stop-Service -Name Spooler";
        executePowerShellCommand(command);
    }

    public static void startSpooler() {
        String command = "Start-Service -Name Spooler";
        executePowerShellCommand(command);
    }

    private static void executePowerShellCommand(String command) {
        try {
            ProcessBuilder builder = new ProcessBuilder("powershell", "-Command", command);
            builder.redirectErrorStream(true);
            Process process = builder.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }

            int exitCode = process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
