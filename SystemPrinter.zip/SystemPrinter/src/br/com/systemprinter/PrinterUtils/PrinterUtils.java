package br.com.systemprinter.PrinterUtils;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

import printerTets.PrinterControlAccess;
import printerTets.PrinterControlFile;


public class PrinterUtils {
	PrinterControlFile pm = new PrinterControlFile();
    public JFrame frame;

    public String ownerName = "Eduardo";
    public String printerName = "OneNote for Windows 10";
    
    // Frame enable functions
    public PrinterUtils() {
        frame = new JFrame();
        frame.setBounds(0, 0, 200, 200);

        PrinterBlockedAccessNative();
        pcAccess();
        
        
        frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				PrinterStartAccessNative();
			}
        });
    }

    //steps of printer
    
    public void PrinterBlockedAccessNative() {
    	System.out.println("Bloqueando impressao");
    	PrinterBlockedAccessNative.stopSpooler();
    }
    
    public void PrinterStartAccessNative() {
    	System.out.println("Liberando impressao");
    	PrinterBlockedAccessNative.startSpooler();
    }
    
    public void pcAccess() {
    	System.out.println("Iniciando o controle de acesso de arquivos");
        PrinterControlAccess.pausePrintJobs(printerName);
    }
    
    // Control of file 
    public void pcFile() {
        try {
            System.out.println("Iniciando a remoção de trabalhos de impressão, mantendo apenas os do proprietário: " + ownerName);
            PrinterControlFile.removeAllPrintJobsExcept(ownerName, printerName);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    
    public static void main(String[] args) {
        PrinterUtils a = new PrinterUtils();
        a.frame.setVisible(true);
    }
    
    
}