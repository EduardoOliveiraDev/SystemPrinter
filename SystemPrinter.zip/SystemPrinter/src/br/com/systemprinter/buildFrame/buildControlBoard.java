package br.com.systemprinter.buildFrame;

import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.standard.OrientationRequested;
import javax.swing.*;
import javax.swing.table.*;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import com.toedter.calendar.JDateChooser;

import br.com.systemprinter.PrinterUtils.ConfigFile;
import br.com.systemprinter.PrinterUtils.PrinterBlockedAccessNative;
import br.com.systemprinter.PrinterUtils.PrinterGetStatus;
import br.com.systemprinter.PrinterUtils.PrinterInput;
import br.com.systemprinter.buildComponents.buildMenuBar;
import br.com.systemprinter.buildMethods.buildMethos;
import br.com.systemprinter.buildMethods.colorList;
import br.com.systemprinter.buildMethods.fontList;
import br.com.systemprinter.dao.PrintHistoricDAO;
import br.com.systemprinter.dao.UserSessionDAO;
import br.com.systemprinter.model.EditingTable;
import br.com.systemprinter.model.PrintHistoricModel;
import br.com.systemprinter.view.FrameControlBoard;
import jnafilechooser.api.JnaFileChooser;

public class buildControlBoard {
	private PrintHistoricDAO dao = new PrintHistoricDAO();
	private static buildControlBoard instance;  
	
	// Constants for page size and layout
	private static final int A4_WIDTH = 379;       // 45% of original width for landscape
	private static final int A4_HEIGHT = 268;      // 45% of original height for landscape
	private static final int MARGIN = 9;           // Margin of 0.5 cm in pixels (about 9 pixels)
	private static final int PAGE_SPACING = 20;    // Space between pages

	// UI components for status
	private JLabel statusLabel; // Label to show status

	// Main panels for the interface
	private JPanel mainPanel; // Main panel of the application
	private JPanel panelGroupAllComponents;       // Panel that groups all visual components
	private JPanel panelHistoric;                 // Panel for the history
	private JPanel panelSearchBar;                // Panel for search bar

	// Search and filter components
	private JTextField searchTextField;           // Text field for search input
	private JDateChooser dateChooserMin;          // Date chooser for minimum date
	private JDateChooser dateChooserMax;          // Date chooser for maximum date
	private JButton buttonClearFilters;           // Button to clear search filters

	// Table and data model for history
	private JTable tableHistoricPrinter;           // Table to show historical data
	private DefaultTableModel dados;               // Model for table data

	// Printing and upload forms
	private JPanel printerForm;                    // Panel for printer settings
	private JLabel pathLabel;                      // Label to show file path

	// Printer-related components
	private JPanel panelPrinter;                   // Panel for printer settings
	private JComboBox<String> comboBoxPrinter;     // Dropdown for selecting printer
	private JComboBox<String> comboBoxPaperSize;   // Dropdown for selecting paper size

	// Components for image upload and display
	private JPanel panelUploadAndShowImageFile;    // Panel for image upload and display
	private JTextField filePathField;              // Text field to show image file path
	private JLabel imageLabel;                     // Label to show image

	// Components for image format settings
	private JPanel componentsFormInput;            // Panel for input form components
	private JPanel componentsImageFormat;          // Panel for image format settings
	private JSpinner spinnerCopyImages;            // Spinner to select number of copies

	// Pagination control
	private int currentOffset = 0;                 // Current page offset
	private final int pageSize = 20;               // Number of items per page
    private Timer timer;
	
	public JPanel containerCenter(JFrame frame) {
	    mainPanel = buildMethos.createPanel(new BorderLayout(), 80, 70, colorList.colorWhiteClear, 0, 0, 0, 0);
	    buildMenuBar menuBar = new buildMenuBar();
	    mainPanel.add(menuBar.containerMain(), BorderLayout.PAGE_START);
	    mainPanel.add(containerGroupAllComponents(frame), BorderLayout.CENTER);
	    return mainPanel;
	}

	private JPanel containerGroupAllComponents(JFrame frame) {
	    panelGroupAllComponents = buildMethos.createPanel(new BorderLayout(), 80, 70, colorList.colorBackgroundWhite, 25, 25, 25, 25);
	    containerPrinter();
	    containerTableHistoric(frame);
	    panelGroupAllComponents.add(panelPrinter, BorderLayout.EAST);
	    panelGroupAllComponents.add(panelHistoric, BorderLayout.WEST);
	    return panelGroupAllComponents;
	}

	private JPanel searchBar(JFrame frame) {
	    panelSearchBar = buildMethos.createPanel(new FlowLayout(FlowLayout.LEFT, 10, 0), 51.5, 4, colorList.colorBackgroundWhite, 0, 0, 0, 0);
	    searchTextField = buildMethos.createTextField("", 26.5, 4, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoPlain16, colorList.colorTextLightGray, "", 0, 10, 0, 10);
	    searchTextField.setText("Pesquisar...");
	    
	    dateChooserMin = buildMethos.createCalendar(6.5, 4, colorList.colorWhiteClear, fontList.RobotoPlain16, colorList.colorBlack, "Insira um data", 0, 0, 0, 0);
	    buildMethos.editCalendar(dateChooserMin, colorList.colorWhiteClear, false, colorList.colorBlack, colorList.colorBlack);
	    
	    dateChooserMax = buildMethos.createCalendar(6.5, 4, colorList.colorWhiteClear, fontList.RobotoPlain16, colorList.colorBlack, "Insira um data", 0, 0, 0, 0);
	    buildMethos.editCalendar(dateChooserMax, colorList.colorWhiteClear, false, colorList.colorBlack, colorList.colorBlack);
	    
	    buttonClearFilters = buildMethos.createJButton("", 2.7, 4, colorList.colorBackgroundWhite, SwingConstants.CENTER, fontList.RobotoBold12, colorList.colorWhiteClear, "Limpar os filtros", 0, 0, 0, 0);
	    buttonClearFilters.setIcon(buildMethos.createImageIcon("../icons/iconClearFilter.png", 2, 3.3));
	    
	    searchBarFunctions();
	    panelSearchBar.add(searchTextField);
	    panelSearchBar.add(dateChooserMin);
	    panelSearchBar.add(dateChooserMax);
	    panelSearchBar.add(buttonClearFilters);
	    return panelSearchBar;
	}

	private void searchBarFunctions() {
	    buildMethos.setPlaceholder(searchTextField, "Pesquisar...");
	    
	    buttonClearFilters.addMouseListener(new MouseAdapter() {
	        @Override
	        public void mouseClicked(MouseEvent e) {
	            // Limpar os campos de filtro
	            searchTextField.setText("Pesquisar...");
	            searchTextField.setForeground(colorList.colorTextLightGray);
	            dateChooserMin.setDate(null);
	            dateChooserMax.setDate(null);

	            // Remover o filtro da tabela
	            if (tableHistoricPrinter != null) {
	                DefaultTableModel model = (DefaultTableModel) tableHistoricPrinter.getModel();
	                TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
	                tableHistoricPrinter.setRowSorter(trs);
	                
	                // Remove qualquer filtro aplicado
	                trs.setRowFilter(null);
	            }
	        }
	    });


	    searchTextField.addKeyListener(new KeyAdapter() {
	        @Override
	        public void keyReleased(KeyEvent e) {
	            applyFiltersSearch();
	        }
	    });
	    
	    dateChooserMin.addPropertyChangeListener(new PropertyChangeListener() {
	        @Override
	        public void propertyChange(PropertyChangeEvent evt) {
	            if ("date".equals(evt.getPropertyName())) {
	                Date selectedDate = dateChooserMin.getDate();
	                if (selectedDate != null) {
	                    applyFiltersSearch();
	                }
	            }
	        }
	    });
	    
	    dateChooserMax.addPropertyChangeListener(new PropertyChangeListener() {
	        @Override
	        public void propertyChange(PropertyChangeEvent evt) {
	            if ("date".equals(evt.getPropertyName())) {
	                Date selectedDate = dateChooserMax.getDate();
	                if (selectedDate != null) {
	                    applyFiltersSearch();
	                }
	            }
	        }
	    });
	}
	
	private void applyFiltersSearch() {
	    if (tableHistoricPrinter == null) {
	        return;
	    }
	
	    DefaultTableModel model = (DefaultTableModel) tableHistoricPrinter.getModel();
	    TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
	    tableHistoricPrinter.setRowSorter(trs);
	
	    List<RowFilter<DefaultTableModel, Object>> filters = new ArrayList<>();
	    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	    Date selectedDateMin = dateChooserMin.getDate();
	    Date selectedDateMax = dateChooserMax.getDate();
	
	    // Validação do intervalo de datas
	    if (selectedDateMin != null && selectedDateMax != null && selectedDateMin.after(selectedDateMax)) {
	        JOptionPane.showMessageDialog(null, "A data mínima não pode ser maior que a data máxima.", "Erro", JOptionPane.ERROR_MESSAGE);
	        dateChooserMin.setDate(null);
	        dateChooserMax.setDate(null);
	        return;
	    }
	
	    // Filtro de data mínima
	    if (selectedDateMin != null) {
	        filters.add(new RowFilter<DefaultTableModel, Object>() {
	            @Override
	            public boolean include(Entry<? extends DefaultTableModel, ? extends Object> entry) {
	                try {
	                    Object cellValue = entry.getValue(1); // Supondo que a data está na coluna 1
	                    Date cellDate;
	
	                    if (cellValue instanceof Timestamp) {
	                        cellDate = new Date(((Timestamp) cellValue).getTime());
	                    } else if (cellValue instanceof Date) {
	                        cellDate = (Date) cellValue;
	                    } else {
	                        return false;
	                    }
	
	                    return !cellDate.before(selectedDateMin);
	                } catch (Exception e) {
	                    return false;
	                }
	            }
	        });
	    }
	
	    // Filtro de data máxima
	    if (selectedDateMax != null) {
	        filters.add(new RowFilter<DefaultTableModel, Object>() {
	            @Override
	            public boolean include(Entry<? extends DefaultTableModel, ? extends Object> entry) {
	                try {
	                    Object cellValue = entry.getValue(1); // Supondo que a data está na coluna 1
	                    Date cellDate;
	
	                    if (cellValue instanceof Timestamp) {
	                        cellDate = new Date(((Timestamp) cellValue).getTime());
	                    } else if (cellValue instanceof Date) {
	                        cellDate = (Date) cellValue;
	                    } else {
	                        return false;
	                    }
	
	                    return !cellDate.after(selectedDateMax);
	                } catch (Exception e) {
	                    return false;
	                }
	            }
	        });
	    }
	
	    // Filtro de texto
	    String textFilter = searchTextField.getText().trim();
	    if (!textFilter.isEmpty() && !textFilter.equals("Pesquisar...")) {
	        filters.add(RowFilter.regexFilter("(?i)" + textFilter, 2)); // Supondo que a coluna 2 é onde o texto será filtrado
	    }
	
	    // Aplica os filtros combinados
	    trs.setRowFilter(RowFilter.andFilter(filters));
	}

	private JPanel containerTableHistoric(JFrame frame) {
	    panelHistoric = buildMethos.createPanel(new BorderLayout(), 45, 40, colorList.colorRed, 0, 0, 0, 0);

	    String[] columnHistoric = {"ID", "Data", "Usuario", "Nº Paginas", "Status"};

	    dados = new DefaultTableModel(columnHistoric, 0) {
	        @Override
	        public boolean isCellEditable(int row, int column) {
	            return false;
	        }
	    };

	    tableHistoricPrinter = new JTable(dados);
	    tableHistoricPrinter.setPreferredScrollableViewportSize(buildMethos.createResponsive(50.5, 55));

	    JScrollPane scrollPane = new JScrollPane(tableHistoricPrinter);

	    EditingTable.setColumnMaxWidths(tableHistoricPrinter, 80, 350, 250, 100, 100);
	    EditingTable.setColumnAlignments(tableHistoricPrinter, SwingConstants.RIGHT, SwingConstants.RIGHT, SwingConstants.RIGHT, SwingConstants.CENTER, SwingConstants.CENTER);
	    EditingTable.setResizingAllowed(tableHistoricPrinter, false);
	    EditingTable.setReorderingAllowed(tableHistoricPrinter, false);
	    tableHistoricPrinter.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 

	    JPanel spacePanel = new JPanel();
	    spacePanel.setPreferredSize(buildMethos.createResponsive(30, 3));
	    spacePanel.setBackground(colorList.colorBackgroundWhite);

	    panelHistoric.add(searchBar(frame), BorderLayout.PAGE_START);
	    panelHistoric.add(spacePanel, BorderLayout.CENTER);
	    panelHistoric.add(scrollPane, BorderLayout.SOUTH);

	    currentOffset = 0;
	    loadMoreData(currentOffset, pageSize);

	    scrollPane.getVerticalScrollBar().addAdjustmentListener(e -> {
	        if (!e.getValueIsAdjusting()) {
	            JScrollBar scrollBar = (JScrollBar) e.getSource();
	            int extent = scrollBar.getModel().getExtent();
	            int maximum = scrollBar.getMaximum();
	            int value = scrollBar.getValue();

	            if (value + extent >= maximum) {
	                currentOffset += pageSize;  
	                loadMoreData(currentOffset, pageSize); 
	            }
	        }
	    });

	    return panelHistoric;
	}

	private void loadMoreData(int offset, int limit) {
	    try {
	        List<PrintHistoricModel> list = dao.listingPrintHistoric(offset, limit);

	        String accessLevel = UserSessionDAO.getInstance().getAccessLevel();
	        list.forEach(i -> {
	            String userCPF = UserSessionDAO.getInstance().getAccessCPF(); // Pega o CPF da sessão do usuário

	            switch (accessLevel.toLowerCase()) {
	                case "diretoria":
	                case "pcg":
	                case "developer":
	                    dados.addRow(new Object[]{
	                        i.getId(),
	                        i.getPrintDate(),
	                        i.getUser(),
	                        i.getNumberOfPages(),
	                        i.getStatus()
	                    });
	                    break;

	                case "professor":
	                case "pca":
	                    if (i.getUserCPF().equals(userCPF)) {
	                        dados.addRow(new Object[]{
	                            i.getId(),
	                            i.getPrintDate(),
	                            i.getUser(),
	                            i.getNumberOfPages(),
	                            i.getStatus()
	                        });
	                    }
	                    break;
	                
	                default:
	                    break;
	            }
	        });


	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Erro ao carregar mais dados: " + e.getMessage());
	    }
	}

	private JPanel containerPrinter() {
	    // Create a panel with a BorderLayout and specific dimensions and colors
	    panelPrinter = buildMethos.createPanel(new BorderLayout(), 26, 40, colorList.colorBackgroundWhite, 0, 0, 0, 0);
	    
	    // Initialize and add the printer form to the center of the panel
	    printerForm();
	    panelPrinter.add(printerForm, BorderLayout.CENTER);
	    
	    return panelPrinter;
	}

	private JPanel printerForm() {
	    printerForm = buildMethos.createPanel(new FlowLayout(FlowLayout.LEFT, 0, 0), 27, 55, colorList.colorBackgroundWhite, 0, 0, 0, 0);
	    
	    JLabel labelTitleWelcome = buildMethos.createJLabel("", 26, 4, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold20, colorList.colorBlack, null, 0, 20, 0, 0);
	    pathLabel = buildMethos.createJLabel("", 26, 4, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoItalic12, colorList.colorTextLightGray, null, 0, 10, 0, 0);
	    JLabel formatLabel = buildMethos.createJLabel("Formatos de arquivos aceitos: JPG, JPEG, PNG e PDF.", 26, 2, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoItalic12, colorList.colorTextLightGray, null, 0, 10, 0, 0);
	    
	    componentsFormInput();
	    componentsImageFormat();
	    printerForm.add(labelTitleWelcome);
	    printerForm.add(pathLabel);
	    printerForm.add(componentsFormInput);
	    printerForm.add(componentsImageFormat);
	    printerForm.add(formatLabel);
	    printerForm.add(componentsSendPrint());
	    
	    return printerForm;
	}

	private JPanel componentsFormInput() {
	    componentsFormInput = buildMethos.createPanel(new FlowLayout(FlowLayout.LEFT, 10, 0), 26, 5, colorList.colorBackgroundWhite, 0, 0, 0, 0);
	    
	    JLabel labelPrinter = buildMethos.createJLabel("Impressora:", 10, 2, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold14, colorList.colorBlack, null, 0, 0, 0, 0);
	    JLabel labelPaperSize = buildMethos.createJLabel("Papel:", 4, 2, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold14, colorList.colorBlack, null, 0, 0, 0, 0);
	    JLabel labelCopysImage = buildMethos.createJLabel("Copias:", 4, 2, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold14, colorList.colorBlack, null, 0, 0, 0, 0);

	    comboBoxPrinter = (JComboBox<String>) buildMethos.createComboBox(10, 3, colorList.colorWhiteClear, fontList.RobotoBold14, colorList.colorBlack, 0, 0, 0, 0);
	    comboBoxPaperSize = (JComboBox<String>) buildMethos.createComboBox(4, 3, colorList.colorWhiteClear, fontList.RobotoBold14, colorList.colorBlack, 0, 0, 0, 0);
	    spinnerCopyImages = buildMethos.createSpinner(4, 3, colorList.colorWhiteClear, fontList.RobotoBold14, colorList.colorBlack);
	    
	    // Configurar o modelo do Spinner com mínimo, máximo e valor inicial
	    SpinnerNumberModel spinnerModel = new SpinnerNumberModel(1, 1, 99, 1); // valor inicial, valor mínimo, valor máximo, incremento
	    spinnerCopyImages.setModel(spinnerModel);
	    
	    // Configurar o valor inicial
	    spinnerCopyImages.setValue(1);

	    // Desabilitar a edição manual do valor
	    JComponent editor = spinnerCopyImages.getEditor();
	    if (editor instanceof JSpinner.NumberEditor) {
	        ((JSpinner.NumberEditor) editor).getTextField().setEditable(false);
	    }
	    
	    componentsFormInputFunctions();
	    componentsFormInput.add(labelPrinter);
	    componentsFormInput.add(labelPaperSize);
	    componentsFormInput.add(labelCopysImage);
	    componentsFormInput.add(comboBoxPrinter);
	    componentsFormInput.add(comboBoxPaperSize);
	    componentsFormInput.add(spinnerCopyImages);
	    
	    return componentsFormInput;
	}

	private void componentsFormInputFunctions() {
	    PrintService[] printServices = PrintServiceLookup.lookupPrintServices(null, null);
	    if (printServices.length == 0) {
	        comboBoxPrinter.addItem("Sem impressora");
	    } else {
	        for (PrintService printService : printServices) {
	            comboBoxPrinter.addItem(printService.getName());
	            PrinterBlockedAccessNative.stopSpooler();
	        }
	    }
	    
	    comboBoxPaperSize.addItem("A4");
	}

	private JPanel componentsImageFormat() {
	    componentsImageFormat = buildMethos.createPanel(new BorderLayout(), 26, 30, colorList.colorBackgroundWhite, 20, 10, 5, 0);
	    
	    panelUploadAndShowImageFile = buildMethos.createPanel(new BorderLayout(), 25, 30, colorList.colorGray, 0, 0, 0, 0);
	    
	    imageLabel = buildMethos.createJLabel("", 20, 20, colorList.colorBackgroundWhite, SwingConstants.CENTER, null, null, null, 0, 0, 0, 0);
	    
	    componentGetFile();
	    panelUploadAndShowImageFile.add(filePathField);
	    componentsImageFormat.add(panelUploadAndShowImageFile, BorderLayout.WEST);
	    return componentsImageFormat;
	}

	private void componentGetFile() {
	    filePathField = buildMethos.createTextField("Clique e Selecione um arquivo.", 26, 20, colorList.colorLightGray, SwingConstants.CENTER, fontList.RobotoItalic18, colorList.colorBlack, null, 0, 0, 0, 0);
	    filePathField.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, colorList.colorGray));
	    filePathField.setEditable(false);
	    filePathField.setHorizontalAlignment(JTextField.CENTER);

	    String[] allowedExtensions = {".jpg", ".jpeg", ".png", ".pdf"};

	    // Adiciona um MouseListener para abrir o seletor de arquivos com clique
	    filePathField.addMouseListener(new MouseAdapter() {
	        @Override
	        public void mouseClicked(MouseEvent e) {
	            JnaFileChooser fc = new JnaFileChooser();
	            fc.addFilter("Imagens e PDF", "jpg", "jpeg", "png", "pdf");
	            fc.setMultiSelectionEnabled(false);
	            boolean fileSelected = fc.showOpenDialog(FrameControlBoard.getInstance().getFrame());
	            if (fileSelected) {
	                File selectedFile = fc.getSelectedFile();
	                if (isValidFileType(selectedFile, allowedExtensions)) {
	                    pathLabel.setText(selectedFile.getAbsolutePath());
	                    showFileImage(selectedFile); // Método para exibir a imagem ou processar o arquivo
	                } else {
	                    JOptionPane.showMessageDialog(null, "Tipo de arquivo inválido. Apenas JPG, JPEG, PNG e PDF são permitidos.");
	                    returnGetFile();
	                }
	            }
	        }
	    });

	    }

	private boolean isValidFileType(File file, String[] allowedExtensions) {
	    String fileName = file.getName().toLowerCase();
	    for (String extension : allowedExtensions) {
	        if (fileName.endsWith(extension)) {
	            return true;
	        }
	    }
	    return false;
	}

	private void showFileImage(File file) {
	    panelUploadAndShowImageFile.removeAll(); // Clear the panel

	    // Add loading status
	    statusLabel = buildMethos.createJLabel("Carregando...", 24, 10, colorList.colorWhiteClear, SwingConstants.CENTER, fontList.RobotoItalic16, colorList.colorBlack, null, 20, 20, 20, 20);
	    
	    panelUploadAndShowImageFile.add(statusLabel, BorderLayout.CENTER);
	    panelUploadAndShowImageFile.revalidate();
	    panelUploadAndShowImageFile.repaint();

	    // Timer to update the loading text
	    Timer timer = new Timer(500, new ActionListener() {
	        private int dots = 0;
	        private String baseText = "Carregando";

	        @Override
	        public void actionPerformed(ActionEvent e) {
	            dots = (dots + 1) % 4; // Cycle through 0 to 3 dots
	            StringBuilder text = new StringBuilder(baseText);
	            for (int i = 0; i < dots; i++) {
	                text.append(".");
	            }
	            statusLabel.setText(text.toString());
	        }
	    });
	    timer.start();

	    // Create and execute the SwingWorker
	    SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
	        @Override
	        protected Void doInBackground() throws Exception {
	            try {
	                if (file.getName().toLowerCase().endsWith(".pdf")) {
	                    processPDF(file);
	                } else {
	                    processImage(file);
	                }
	            } catch (IOException e) {
	                e.printStackTrace();
	                JOptionPane.showMessageDialog(null, "Erro ao carregar o arquivo.", "Error", JOptionPane.ERROR_MESSAGE);
	            }
	            return null;
	        }

	        @Override
	        protected void done() {
	            // Stop the timer
	            timer.stop();

	            // Remove loading status and update the panel
	            panelUploadAndShowImageFile.remove(statusLabel);
	            panelUploadAndShowImageFile.revalidate();
	            panelUploadAndShowImageFile.repaint();
	        }
	    };

	    worker.execute();
	}
	
	private void processPDF(File file) throws IOException {
	    try (PDDocument document = PDDocument.load(file)) {
	        if (document.getNumberOfPages() > 1) {
	            createMultiPagePreview(document);
	        } else {
	            BufferedImage bufferedImage = renderPDFPage(document, 0);
	            BufferedImage finalImage = prepareImage(bufferedImage);
	            displayImage(finalImage);
	        }
	    } 
	}

	private void createMultiPagePreview(PDDocument document) throws IOException {
	    int numPages = document.getNumberOfPages();
	    JPanel multiPagePanel = new JPanel();
	    multiPagePanel.setLayout(new BoxLayout(multiPagePanel, BoxLayout.Y_AXIS)); // Vertical layout for pages

	    for (int i = 0; i < numPages; i++) {
	        BufferedImage pageImage = renderPDFPage(document, i);
	        BufferedImage finalImage = prepareImage(pageImage);
	        JLabel pageLabel = new JLabel(new ImageIcon(finalImage));
	        pageLabel.setHorizontalAlignment(JLabel.CENTER); // Center align the image horizontally
	        pageLabel.setVerticalAlignment(JLabel.CENTER);   // Center align the image vertically

	        // Add a tooltip with the page number and total
	        pageLabel.setToolTipText("Page " + (i + 1) + " / " + numPages);

	        // Add a panel for the page with margins and space
	        JPanel pagePanel = new JPanel();
	        pagePanel.setLayout(new BorderLayout());
	        pagePanel.setPreferredSize(new Dimension(A4_WIDTH, A4_HEIGHT + PAGE_SPACING));
	        pagePanel.add(pageLabel, BorderLayout.CENTER);

	        multiPagePanel.add(pagePanel);
	        if (i < numPages - 1) {
	            multiPagePanel.add(Box.createRigidArea(new Dimension(0, PAGE_SPACING))); // Space between pages
	        }
	    }

	    JScrollPane scrollPane = new JScrollPane(multiPagePanel);
	    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

	    panelUploadAndShowImageFile.setLayout(new BorderLayout());
	    panelUploadAndShowImageFile.add(scrollPane, BorderLayout.CENTER);

	    panelUploadAndShowImageFile.revalidate();
	    panelUploadAndShowImageFile.repaint();
	}

	private BufferedImage renderPDFPage(PDDocument document, int pageIndex) throws IOException {
	    PDFRenderer pdfRenderer = new PDFRenderer(document);
	    return pdfRenderer.renderImageWithDPI(pageIndex, 300); // Render a specific page of the PDF
	}

	private BufferedImage prepareImage(BufferedImage image) {
	    // Check the orientation of the image and rotate if necessary
	    if (image.getHeight() > image.getWidth()) {
	        image = rotateImage(image, -90); // Rotate the image 90 degrees to the left
	    }

	    // Scale the image to fit the panel, considering margins
	    BufferedImage scaledImage = scaleImage(image, A4_WIDTH - 2 * MARGIN, A4_HEIGHT - 2 * MARGIN);
	    BufferedImage finalImage = new BufferedImage(A4_WIDTH, A4_HEIGHT, BufferedImage.TYPE_INT_ARGB);
	    Graphics2D g2d = finalImage.createGraphics();

	    // Fill the image in the center, leaving margins around it
	    g2d.setColor(Color.WHITE); // Set the background color of the margin
	    g2d.fillRect(0, 0, A4_WIDTH, A4_HEIGHT); // Fill the background with white
	    int x = (A4_WIDTH - scaledImage.getWidth()) / 2;
	    int y = (A4_HEIGHT - scaledImage.getHeight()) / 2;
	    g2d.drawImage(scaledImage, x, y, null);
	    g2d.dispose();

	    return finalImage;
	}

	private void processImage(File file) throws IOException {
	    BufferedImage originalImage = ImageIO.read(file);
	    if (originalImage == null) {
	        JOptionPane.showMessageDialog(null, "Unable to load the image. The file format may be incompatible.", "Error", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    BufferedImage finalImage = prepareImage(originalImage);
	    displayImage(finalImage);
	}

	private void displayImage(BufferedImage image) {
	    // Adjust the preferred size of the JLabel to match the fixed size of the panel
	    imageLabel.setPreferredSize(new Dimension(A4_WIDTH, A4_HEIGHT));
	    imageLabel.setIcon(new ImageIcon(image));
	    imageLabel.setText(""); // Remove any text, if present

	    // Create a panel to add the JLabel
	    JPanel imagePanel = new JPanel();
	    imagePanel.setLayout(new BorderLayout());
	    imagePanel.setPreferredSize(new Dimension(A4_WIDTH, A4_HEIGHT));
	    imagePanel.add(imageLabel, BorderLayout.CENTER);

	    // Create a JScrollPane for the image panel
	    JScrollPane scrollPane = new JScrollPane(imagePanel);
	    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

	    // Set the preferred size of the main panel to the JScrollPane
	    panelUploadAndShowImageFile.setLayout(new BorderLayout());
	    panelUploadAndShowImageFile.add(scrollPane, BorderLayout.CENTER);

	    // Revalidate and repaint the panel to reflect changes
	    panelUploadAndShowImageFile.revalidate();
	    panelUploadAndShowImageFile.repaint();
	}

	private BufferedImage rotateImage(BufferedImage image, int angle) {
	    double radians = Math.toRadians(angle);
	    double sin = Math.abs(Math.sin(radians));
	    double cos = Math.abs(Math.cos(radians));
	    int width = image.getWidth();
	    int height = image.getHeight();
	    int newWidth = (int) Math.floor(width * cos + height * sin);
	    int newHeight = (int) Math.floor(height * cos + width * sin);
	    BufferedImage rotatedImage = new BufferedImage(newWidth, newHeight, image.getType());
	    Graphics2D g2d = rotatedImage.createGraphics();
	    g2d.translate((newWidth - width) / 2, (newHeight - height) / 2);
	    g2d.rotate(radians, width / 2, height / 2);
	    g2d.drawRenderedImage(image, null);
	    g2d.dispose();
	    return rotatedImage;
	}

	private BufferedImage scaleImage(BufferedImage image, int width, int height) {
	    int imageWidth = image.getWidth();
	    int imageHeight = image.getHeight();
	    double aspectRatio = (double) imageWidth / imageHeight;

	    // Determine the new width and height while maintaining the aspect ratio
	    int newWidth, newHeight;
	    if (width / (double) height > aspectRatio) {
	        newWidth = (int) (height * aspectRatio);
	        newHeight = height;
	    } else {
	        newWidth = width;
	        newHeight = (int) (width / aspectRatio);
	    }

	    // Resize the image
	    Image scaledImage = image.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
	    BufferedImage bufferedScaledImage = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
	    Graphics2D g2d = bufferedScaledImage.createGraphics();
	    g2d.drawImage(scaledImage, 0, 0, null);
	    g2d.dispose();

	    return bufferedScaledImage;
	}

	private void returnGetFile() {
	    pathLabel.setText("");
	    panelUploadAndShowImageFile.removeAll();
	    panelUploadAndShowImageFile.add(filePathField);
	    spinnerCopyImages.setValue(1);
	    panelUploadAndShowImageFile.revalidate();
	    panelUploadAndShowImageFile.repaint();
	}

	private JPanel componentsSendPrint() {
		JPanel componentsSendPrint = buildMethos.createPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10), 26, 4,
				colorList.colorBackgroundWhite, 0, 0, 0, 0);
		JButton btnSend = buildMethos.createJButton("Imprimir", 5, 3, colorList.colorCyanTiber, SwingConstants.CENTER,
				fontList.RobotoBold14, colorList.colorWhiteClear, null, 0, 0, 0, 0);
		JButton btnCanel = buildMethos.createJButton("Cancelar", 5, 3, colorList.colorCyanTiber, SwingConstants.CENTER,
				fontList.RobotoBold14, colorList.colorWhiteClear, null, 0, 0, 0, 0);

		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!pathLabel.getText().isEmpty()) {
					int valueCopys = (int) spinnerCopyImages.getValue();
					int valuePages = 1;

					File file = new File(pathLabel.getText());
					if (pathLabel.getText().toLowerCase().endsWith(".pdf")) {
			            try 
			            	(PDDocument document = PDDocument.load(file)) {
			                valuePages = document.getNumberOfPages();
			            } catch (IOException e1) {
			                e1.printStackTrace();
			                JOptionPane.showMessageDialog(null, "Erro ao carregar o arquivo PDF.", "Erro", JOptionPane.ERROR_MESSAGE);
			            }
					}

					int response = JOptionPane.showConfirmDialog(null,
							"Deseja imprimir este arquivo com:" + "\nPaginas: " + valuePages + "\ncopias: " + valueCopys,
							"Confirmação", JOptionPane.YES_NO_OPTION);

					if (response == JOptionPane.YES_OPTION) {
						new Thread(() -> {
							PrinterBlockedAccessNative.startSpooler();
							sendPreviewToPrinter();
						}).start();
					}
				} else {
					JOptionPane.showMessageDialog(null, "Nenhum arquivo carregado!", "Erro", JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnCanel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				returnGetFile();
			}
		});

		componentsSendPrint.add(btnCanel);
		componentsSendPrint.add(btnSend);
		return componentsSendPrint;
	}

	private void sendPreviewToPrinter() {
		// variable treatment 
		String path = pathLabel.getText();
		String printerName = comboBoxPrinter.getSelectedItem().toString();
	    
		int copy = (int) spinnerCopyImages.getValue();
	    String mediaSize = comboBoxPaperSize.getSelectedItem().toString(); 
	    OrientationRequested orientation = OrientationRequested.LANDSCAPE;
	    
	    PrinterInput.printFile(path, printerName, copy, mediaSize, orientation);
	}
	
	
	public static buildControlBoard getInstance() {
	    if (instance == null) {
	        instance = new buildControlBoard();
	    }
	    return instance;
	}
}
