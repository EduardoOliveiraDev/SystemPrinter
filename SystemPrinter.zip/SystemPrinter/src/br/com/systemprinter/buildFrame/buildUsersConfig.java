package br.com.systemprinter.buildFrame;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import br.com.systemprinter.buildMethods.buildMethos;
import br.com.systemprinter.buildMethods.colorList;
import br.com.systemprinter.buildMethods.fontList;
import br.com.systemprinter.dao.UserDAO;
import br.com.systemprinter.dao.UserSessionDAO;
import br.com.systemprinter.model.EditingTable;
import br.com.systemprinter.model.UserModel;


public class buildUsersConfig {
	private UserDAO dao = new UserDAO();
	public static buildUsersConfig instance;
	
	private JPanel containerTableListUsers;
	private JPanel containerFormInputInfos;
	private JPanel containerForm;
	private JPanel containerComponentsLoginImage;
	private JPanel containerGroupButtons;
	
	private JTable tableListUsers;
	private DefaultTableModel dados;
	private int idUser = -1;
	
	private JButton buttonGoBackForm;
	private JTextField textfieldCPF;
	private JTextField textfieldUserName;
	private JTextField textfieldPassword;
	private JTextField textfieldConfirm;
	private JTextField textfieldLevel;
	private JComboBox<String> comboBoxAccessLevel;
	private JLabel userCreateLabelInfos;
	private JLabel passwordLabelInfos;
	
	private JButton buttonShowPassword;
	private JButton buttonTradePassword;
	private JButton buttonChangeLevel;
	private JButton buttonSaveInfos;
	private JButton buttonDeleteUsers;
	private JButton buttonCreateusers;
	private boolean listenerEnabled = true;
	
    private EmptyBorder paddingBorder = new EmptyBorder(0, 10, 0, 10); 
    private LineBorder lineBorderNeutral = new LineBorder(colorList.colorBackgroundWhite, 2);
    private LineBorder lineBorderRed = new LineBorder(colorList.colorRed, 2);
    private LineBorder lineBorderGreen = new LineBorder(colorList.colorDarkGreen, 2);

    private Border compoundBorderNeutral = new CompoundBorder(lineBorderNeutral, paddingBorder);
    private Border compoundBorderRed = new CompoundBorder(lineBorderRed, paddingBorder);
    private Border compoundBorderGreen = new CompoundBorder(lineBorderGreen, paddingBorder);
	
	private JLabel image = buildMethos.createLabelImage("../icons/ImageUserChange.jpg", 16, 28);
	
	public void listingUsers() throws SQLException {
	    List<UserModel> list = dao.listingDatabaseTableUsers();
	    dados.setNumRows(0);
	    
	    list.forEach(i -> { dados.addRow(new Object[] {
	    		i.getId(),
	    		i.getCPF(),
	    		i.getUser(),
	    		i.getLevel()
	    	});
	    });
	    
	}
	
	public JPanel containerMain(JFrame frame) {
		JPanel containerMain = buildMethos.createPanel(new FlowLayout(FlowLayout.LEFT, 20,20), 50, 50, colorList.colorWhiteClear, 0,0,0,0);
		containerMain.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, colorList.colorBlack));
		
		containerTableUsersInfo();
		containerForm();
		containerMain.add(containerTableListUsers);
		containerMain.add(containerFormInputInfos);
		return containerMain;
	}
	
	@SuppressWarnings("serial")
	private JPanel containerTableUsersInfo() {
	    containerTableListUsers = buildMethos.createPanel(new BorderLayout(), 16, 46, colorList.colorRed, 0, 0, 0, 0);

	    String[] columnHistoric = {"ID", "CPF", "Usuario", "Acesso"};
	    dados = new DefaultTableModel(columnHistoric, 0) {
			public boolean isCellEditable(int row, int column) {
	            return false;
	        }
	    };
	    
	    tableListUsers = new JTable(dados);
	    tableListUsers.setPreferredScrollableViewportSize(buildMethos.createResponsive(15, 46));

	    EditingTable.setColumnMaxWidths(tableListUsers, 30, 100, 100, 80);
	    EditingTable.setColumnAlignments(tableListUsers, SwingConstants.CENTER, SwingConstants.CENTER, SwingConstants.RIGHT, SwingConstants.CENTER);
	    EditingTable.setResizingAllowed(tableListUsers, false);
	    EditingTable.setReorderingAllowed(tableListUsers, false);
	    tableListUsers.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

	    containerTableListUsers.add(new JScrollPane(tableListUsers), BorderLayout.CENTER);
	    return containerTableListUsers;
	}

	private JPanel containerForm() {
		containerFormInputInfos = buildMethos.createPanel(new BorderLayout(), 30.5, 46, colorList.colorWhiteClear, 0, 0, 0, 0);
		JPanel panelTitle = buildMethos.createPanel(new FlowLayout(FlowLayout.LEFT, 0, 0), 32.5, 5, colorList.colorWhiteClear, 0, 0, 0, 0);
		
		JLabel title = buildMethos.createJLabel("Informações do usuario", 12, 5, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold18, colorList.colorBlack, "Titulo", 0, 0, 0, 0);
		buttonGoBackForm = buildMethos.createJButton("X", 2, 3, colorList.colorWhiteClear, SwingConstants.CENTER, fontList.RobotoBold18, colorList.colorBlack, "Cancelar", 0, 0, 0, 0);
		buttonGoBackForm.setVisible(false);
		panelTitle.add(title);
		panelTitle.add(buttonGoBackForm);
		
		containerFormInputInfos();
		containerImage();
		containerFormInputInfos.add(panelTitle, BorderLayout.NORTH);
		containerFormInputInfos.add(containerComponentsLoginImage, BorderLayout.EAST);
		containerFormInputInfos.add(containerForm, BorderLayout.WEST);
		return containerFormInputInfos;
	}
	
	@SuppressWarnings("unchecked")
	private JPanel containerFormInputInfos() {
		containerForm = buildMethos.createPanel(new BorderLayout(), 20, 30, colorList.colorRed, 0, 0, 0, 0);
		
		JPanel formPanel = buildMethos.createPanel(new FlowLayout(FlowLayout.LEFT, 0, 10), 20, 25, colorList.colorWhiteClear, 0, 0, 0, 0);
		textfieldCPF = buildMethos.createTextField("", 14, 3.5, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold14, colorList.colorTextLightGray, "Insira seu CPF", 0, 10, 0, 10);
		textfieldUserName = buildMethos.createTextField("", 14, 3.5, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold14, colorList.colorTextLightGray, "Insira seu nome", 0, 10, 0, 10);
		textfieldPassword = buildMethos.createTextField("", 14, 3.5, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold14, colorList.colorBlack, "Digite uma senha", 0, 10, 0, 10);
		textfieldConfirm = buildMethos.createTextField("", 14, 3.5, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold14, colorList.colorBlack, "Confirme sua senha", 0, 10, 0, 10);
		textfieldLevel = buildMethos.createTextField("Nivel", 14, 3.5, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold14, colorList.colorTextLightGray, "", 0, 10, 0, 10);
		
		userCreateLabelInfos = buildMethos.createJLabel("", 14, 5, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold12, colorList.colorTextLightGray, "", 0, 0, 0, 0);
		userCreateLabelInfos.setText("<html> - O usuário deve ter entre 2 a 40 caracteres.<br>"
				+ "- A senha deve ter entre 4 a 20 caracteres.</html>");
		
		passwordLabelInfos = buildMethos.createJLabel("", 14, 5, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold12, colorList.colorTextLightGray, "", 0, 0, 0, 0);
		passwordLabelInfos.setText("<html> - A senha deve ter entre 4 a 20 caracteres.</html>");

		textfieldCPF.setBorder(compoundBorderNeutral);
		textfieldUserName.setBorder(compoundBorderNeutral);
		textfieldPassword.setBorder(compoundBorderNeutral);
		textfieldConfirm.setBorder(compoundBorderNeutral);
		buildMethos.setPlaceholder(textfieldCPF, "CPF");
		buildMethos.setPlaceholder(textfieldUserName, "Usuario");
		buildMethos.setPlaceholder(textfieldPassword, "Senha");
		buildMethos.setPlaceholder(textfieldConfirm, "Confirmar Senha");
		
		comboBoxAccessLevel = (JComboBox<String>) buildMethos.createComboBox(14, 3.5, colorList.colorBackgroundWhite, fontList.RobotoItalic16, colorList.colorBlack, 0, 0, 0, 0);
		comboBoxAccessLevel.addItem("Professor");
		comboBoxAccessLevel.addItem("PCA"); 
		comboBoxAccessLevel.addItem("PCG");
		comboBoxAccessLevel.addItem("Diretoria");
		
		formPanel.add(textfieldCPF);
        formPanel.add(textfieldUserName);
        formPanel.add(textfieldPassword);
        formPanel.add(textfieldConfirm);
        formPanel.add(textfieldLevel);
        formPanel.add(comboBoxAccessLevel);
        formPanel.add(userCreateLabelInfos);
        formPanel.add(passwordLabelInfos);
        
        containerFormButtons();
        containerFormInputInfosFunctions();
        JPanel alainButtons = buildMethos.createPanel(new FlowLayout(FlowLayout.LEFT, 0, 0), 16, 11, colorList.colorWhiteClear, 0, 0, 0, 0);
        alainButtons.add(containerGroupButtons);
        
        containerForm.add(formPanel, BorderLayout.CENTER);
        containerForm.add(alainButtons, BorderLayout.PAGE_END);
		return containerForm;
	}
	
	private void containerFormInputInfosFunctions() {
		textfieldConfirm.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				if (textfieldPassword.getText().equalsIgnoreCase(textfieldConfirm.getText()) && 
						textfieldPassword.getText().length() >= 4 && 
			        	textfieldPassword.getText().length() <= 20) {
					
					textfieldPassword.setBorder(compoundBorderGreen);
					textfieldConfirm.setBorder(compoundBorderGreen);
				} else {
					textfieldPassword.setBorder(compoundBorderRed);
					textfieldConfirm.setBorder(compoundBorderRed);
				}
				
			}
		});
		
        ListSelectionModel selectionModel = tableListUsers.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && listenerEnabled) {
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            int selectedRow = tableListUsers.getSelectedRow();
                            if (selectedRow != -1) {
                                Object userId = tableListUsers.getValueAt(selectedRow, 0);
                                Object userCPF = tableListUsers.getValueAt(selectedRow, 1);
                                Object userName = tableListUsers.getValueAt(selectedRow, 2);
                                Object userLevel = tableListUsers.getValueAt(selectedRow, 3);

                                idUser = (int) userId;
                                textfieldCPF.setText(userCPF.toString());
                                textfieldCPF.setForeground(colorList.colorBlack);
                                textfieldUserName.setText(userName.toString());
                                textfieldUserName.setForeground(colorList.colorBlack);
                                textfieldLevel.setText(userLevel.toString());
                            }
                        }
                    });
                }
            }
        });
	}
	
	private JPanel containerFormButtons() {
		containerGroupButtons =  buildMethos.createPanel(new FlowLayout(FlowLayout.CENTER, 5, 10), 16, 11, colorList.colorWhiteClear, 0, 0, 0, 0);
		buttonShowPassword = buildMethos.createJButton("Ver Senha", 5, 4, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold12, colorList.colorWhiteClear, "Mostrar Senha", 0, 0, 0, 0);
		buttonCreateusers = buildMethos.createJButton("Criar Usuario", 5, 4, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold12, colorList.colorWhiteClear, "Criar",0, 0, 0, 0);
		buttonSaveInfos = buildMethos.createJButton("Salvar", 5, 4, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold12, colorList.colorWhiteClear, "Salvar",0, 0, 0, 0);
		buttonTradePassword = buildMethos.createJButton("Trocar Senha", 5, 4, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold12, colorList.colorWhiteClear, "Mudar Senha",0, 0, 0, 0);
		buttonChangeLevel = buildMethos.createJButton("Trocar Acesso", 5, 4, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold12, colorList.colorWhiteClear, "Mudar Nivel",0, 0, 0, 0);
		buttonDeleteUsers = buildMethos.createJButton("Desativar", 5, 4, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold12, colorList.colorWhiteClear, "Deletar",0, 0, 0, 0);
		
		containerFormButtonsFunctions();
		// DELETE all icons
//		buttonShowPassword.setIcon(buildMethos.createImageIcon("../images/iconPassword.png", 1, 2));
//		buttonCreateusers.setIcon(buildMethos.createImageIcon("../images/iconCreateUser.png", 2.5, 4.5));
//		buttonSaveInfos.setIcon(buildMethos.createImageIcon("../images/iconSave.png", 2.5, 4.5));
//		buttonTradePassword.setIcon(buildMethos.createImageIcon("../images/iconChangePassword.png", 2, 3.6));
//		buttonChangeLevel.setIcon(buildMethos.createImageIcon("../images/iconChangeLevel.png", 2, 3.6));
//		buttonDeleteUsers.setIcon(buildMethos.createImageIcon("../images/iconDelete.png", 2, 3.6));
		
		containerGroupButtons.add(buttonShowPassword);
		containerGroupButtons.add(buttonCreateusers);
		containerGroupButtons.add(buttonSaveInfos);		
		containerGroupButtons.add(buttonTradePassword);
		containerGroupButtons.add(buttonChangeLevel);
		containerGroupButtons.add(buttonDeleteUsers);
		return containerGroupButtons;
	}
	
	private void containerFormButtonsFunctions() {
		startingForm();
		buttonGoBackForm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetForm();
			}
		});
		
		buttonShowPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String access_CPF = UserSessionDAO.getInstance().getAccessCPF();
				String access_user = UserSessionDAO.getInstance().getCurrentUser();
				List<String> access_level = Arrays.asList("PGC", "PCA", "Professor", "INATIVO");
				
                int selectedRow = tableListUsers.getSelectedRow();
                if (selectedRow == -1) {
					JOptionPane.showMessageDialog(null, "Selecione um usuario.", "Visualizar senha", JOptionPane.WARNING_MESSAGE);
				}
                
                if (selectedRow != -1) {
                	Object CPF = tableListUsers.getValueAt(selectedRow, 1);
                	Object user = tableListUsers.getValueAt(selectedRow, 2);
                	UserModel userInfo = new UserModel(idUser, access_CPF, access_user, access_user, access_user);
                	
                	if (UserSessionDAO.getInstance().getAccessIdUser() == 0) {
                		try {
							JOptionPane.showMessageDialog(null, "User: " + user + "\nPassword: " + dao.getPassword(userInfo), "Dev Access - Show Password", JOptionPane.INFORMATION_MESSAGE);
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
                	
                    if (UserSessionDAO.getInstance().getAccessIdUser() != 0) {
                    	String access_password = JOptionPane.showInputDialog("Insira sua sennha para liberar acesso");
                    	dao.isValidUser(access_CPF, access_password, access_level);
                    	try {
							buildMethos.showMessageTemp("CPF: " + CPF + "\nUsuario: " + user + "\nSenha: " + dao.getPassword(userInfo), "Mensagem temporaria", JOptionPane.INFORMATION_MESSAGE , 5);
						} catch (Exception e1) {
							e1.printStackTrace();
						} 
					}
                }
			}
		});
		
		buttonTradePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                int selectedRow = tableListUsers.getSelectedRow();
                if (selectedRow == -1) {
					JOptionPane.showMessageDialog(null, "Selecione um usuario.", "Trocar senha", JOptionPane.WARNING_MESSAGE);
				}
                
                if (selectedRow != -1) {
                	editingForm();
                	textfieldPassword.setVisible(true);
                	textfieldConfirm.setVisible(true);
                	
                	textfieldLevel.setVisible(false);
                	passwordLabelInfos.setVisible(true);
                }
			}
		});
		
		buttonChangeLevel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                int selectedRow = tableListUsers.getSelectedRow();
                if (selectedRow == -1) {
					JOptionPane.showMessageDialog(null, "Selecione um usuario.", "Trocar nivel", JOptionPane.WARNING_MESSAGE);
				}
                
                if (selectedRow != -1) {
                	editingForm();
                	comboBoxAccessLevel.setVisible(true);
                	textfieldLevel.setVisible(false);
                }
			}
		});
		
		buttonSaveInfos.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Create user
		        if (textfieldConfirm.isVisible() && comboBoxAccessLevel.isVisible()) {
		        	if (checkPassword() && checkUsername() && checkCPF()) {
		        		UserModel userInfo = new UserModel(idUser, textfieldCPF.getText(), textfieldUserName.getText(), textfieldPassword.getText(), comboBoxAccessLevel.getSelectedItem().toString());
		        		try {
							dao.createUser(userInfo);
							JOptionPane.showMessageDialog(null, "Usuario " + textfieldUserName.getText() + " Criado com sucesso!", "Usuario criado", JOptionPane.INFORMATION_MESSAGE);
							resetForm();
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				}
		    	
		    	// change password
		    	if (textfieldConfirm.isVisible() && !comboBoxAccessLevel.isVisible()) {
			        if (checkPassword()) {
			        	UserModel userInfo = new UserModel(idUser, textfieldPassword.getText());
				             
			        	try {
			        		dao.changeUsersInformation(userInfo);
			        		JOptionPane.showMessageDialog(null, "Senha trocada com sucesso!", "Troca de senha", JOptionPane.INFORMATION_MESSAGE);
			        		resetForm();
			        	} catch (Exception e1) {
			        		System.out.println("Erro ao atualizar informações do usuário: " + e1.getMessage());
			        	} 
			        }
				}
		    	
		    	
		        // change access level
		        if (comboBoxAccessLevel.isVisible() && !textfieldConfirm.isVisible()) {
		           if (textfieldCPF.getText() == UserSessionDAO.getInstance().getAccessCPF()) {
					
		        	   UserModel userInfo = new UserModel(comboBoxAccessLevel.getSelectedItem().toString(), idUser);
			            
			            try {
							dao.changeUsersInformation(userInfo);
				            JOptionPane.showMessageDialog(null, "Nivel trocado com sucesso!", "Troca de nivel", JOptionPane.INFORMATION_MESSAGE);
				            resetForm();
						} catch (Exception e2) {
							System.out.println("Erro ao atualizar informações do usuário: " + e2.getMessage());
						}
		        	   
		        	   
		           } else {
		        	   JOptionPane.showMessageDialog(null, "Você não pode trocar seu próprio nivel de usuario!", "Bloqueado", JOptionPane.INFORMATION_MESSAGE);
		           }
				}
		        
		        
		    }
		});
		
		buttonDeleteUsers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tableListUsers.getSelectedRow() == -1) {
					JOptionPane.showMessageDialog(null, "Selecione um usuario.", "Deletar um usuario", JOptionPane.WARNING_MESSAGE);
				} 
				
				if(tableListUsers.getSelectedRow() != -1) {
					// block user auto delete your account
					if (idUser == UserSessionDAO.getInstance().getAccessIdUser()) {
						JOptionPane.showMessageDialog(null, "Você não pode deixar sua própria conta inativa!", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					if (idUser != UserSessionDAO.getInstance().getAccessIdUser()) {

				        int response = JOptionPane.showConfirmDialog(null, 
				                "Você tem certeza que deseja deletar o usuario " + textfieldUserName.getText() + "?", 
				                "Confirmação", 
				                JOptionPane.YES_NO_OPTION, 
				                JOptionPane.QUESTION_MESSAGE);

				        if (response == JOptionPane.YES_OPTION) {
							UserModel userInfo = new UserModel("INATIVO", idUser);
							
							try {
								dao.changeUsersInformation(userInfo);
								JOptionPane.showMessageDialog(null, "Usuario deletado com sucesso", "Deletar usuario", JOptionPane.INFORMATION_MESSAGE);
								resetForm();
							} catch (Exception e1) {
								e1.printStackTrace();
							}
				        }
				        
				        if (response == JOptionPane.NO_OPTION) {
				        	System.out.println("Usuário cancelou a ação.");
				        }
					
					}

				}
			
			}
		});
	
		buttonCreateusers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editingForm();
				textfieldCPF.setEditable(true);
				textfieldUserName.setEditable(true);
				textfieldPassword.setVisible(true);
				textfieldConfirm.setVisible(true);
				comboBoxAccessLevel.setVisible(true);
				
				textfieldLevel.setVisible(false);
				userCreateLabelInfos.setVisible(true);
				textfieldCPF.setText("CPF");
				textfieldUserName.setText("Usuario");
				textfieldUserName.setForeground(colorList.colorTextLightGray);
				textfieldPassword.setText("Senha");
				
				textfieldUserName.addKeyListener(new KeyAdapter() {
					public void keyReleased(KeyEvent e) {
						if (textfieldUserName.getText().length() > 1 && 
							textfieldUserName.getText().length() < 40) {
							textfieldUserName.setBorder(compoundBorderGreen);
						} else {
							textfieldUserName.setBorder(compoundBorderRed);
							
							
						}
					}
				});
				
				textfieldCPF.addKeyListener(new KeyAdapter() {
					public void keyReleased(KeyEvent e) {
						if (textfieldCPF.getText().length() == 11 && !isCPFinTable(textfieldCPF.getText())) {
							
							textfieldCPF.setBorder(compoundBorderGreen);
							buttonSaveInfos.setEnabled(true);
						} else {
							textfieldCPF.setBorder(compoundBorderRed);
							buttonSaveInfos.setEnabled(false);
						}
					}
				});
				
				
				
			}
		});
	}
	
	private boolean checkUsername() {
        if (textfieldUserName.getText().length() < 2) {
			JOptionPane.showMessageDialog(null, "O nome de usuario deve ter 2 caracteres no minimo", "Erro", JOptionPane.ERROR_MESSAGE);
			return false;
        }
		
        if (textfieldUserName.getText().length() > 40) {
			JOptionPane.showMessageDialog(null, "O nome de usuario deve ter 40 caracteres no maximo", "Erro", JOptionPane.ERROR_MESSAGE);
			return false;
        }
        
        if (textfieldUserName.getText().equalsIgnoreCase("Usuario") || textfieldUserName.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "O nome de usuario esta vazio!", "Erro", JOptionPane.ERROR_MESSAGE);
			return false;
        }
        
        if (textfieldUserName.getText().equalsIgnoreCase("Developer") || textfieldUserName.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Nome de usuario bloqueado!", "Erro", JOptionPane.ERROR_MESSAGE);
			return false;
        }
        
		return true;
	}
	
	private boolean checkPassword() {
        if (!textfieldPassword.getText().equals(textfieldConfirm.getText())) {
			JOptionPane.showMessageDialog(null, "Senhas incompativeis", "Senhas Erradas", JOptionPane.ERROR_MESSAGE);
			return false;
		}
        
        if (textfieldPassword.getText().length() < 4) {
			JOptionPane.showMessageDialog(null, "a senha deve ter 4 caracteres no minimo", "Erro", JOptionPane.ERROR_MESSAGE);
			return false;
        }
        
        if (textfieldPassword.getText().length() > 20) {
			JOptionPane.showMessageDialog(null, "a senha deve ter 20 caracteres no maximo", "Erro", JOptionPane.ERROR_MESSAGE);
			return false;
        }
        
        return true;
	}
	
	private boolean checkCPF() {
		if (textfieldCPF.getText().length() != 11) {
			JOptionPane.showMessageDialog(null, "CPF Invalido, deve conter 11 digitos", "CPF Errado", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		
		return true;
	}
	
	private boolean isCPFinTable(String CPF) {
	    int rowCount = tableListUsers.getRowCount();
	    int usernameColumnIndex = 1; 

	    for (int i = 0; i < rowCount; i++) {
	        String existingCPF = tableListUsers.getValueAt(i, usernameColumnIndex).toString();
	        if (existingCPF.equals(CPF) && !CPF.equals("54566105822")) {
	            return true; 
	        }
	    }
	    return false; 
	}
	
	private void editingForm() {
		buttonGoBackForm.setVisible(true);
    	listenerEnabled = false;
    	
    	buttonShowPassword.setEnabled(false);
    	buttonTradePassword.setEnabled(false);
    	buttonChangeLevel.setEnabled(false);
    	buttonSaveInfos.setEnabled(true);
    	buttonDeleteUsers.setEnabled(false);
    	buttonCreateusers.setEnabled(false);
	}
	
	private void startingForm() {
		// Enable
		textfieldCPF.setEditable(false);
		textfieldUserName.setEditable(false);
		textfieldLevel.setEditable(false);
		buttonSaveInfos.setEnabled(false);
		
		// Visible
		textfieldPassword.setVisible(false);
		textfieldConfirm.setVisible(false);
		comboBoxAccessLevel.setVisible(false);
		userCreateLabelInfos.setVisible(false);
		passwordLabelInfos.setVisible(false);
		
	}
	
	private void resetForm() {
		try {
			listingUsers();
		} catch (Exception e) {
		}
		
		// set tetx
		textfieldCPF.setText("CPF");
		textfieldCPF.setForeground(colorList.colorTextLightGray);
		textfieldUserName.setText("Usuario");
		textfieldUserName.setForeground(colorList.colorTextLightGray);
		buildMethos.setPlaceholder(textfieldPassword, "Senha");
		buildMethos.setPlaceholder(textfieldConfirm, "Confirmar Senha");
		textfieldLevel.setText("Level");
		
		textfieldCPF.setBorder(compoundBorderNeutral);
		textfieldUserName.setBorder(compoundBorderNeutral);
		textfieldPassword.setBorder(compoundBorderNeutral);
		textfieldConfirm.setBorder(compoundBorderNeutral);

		listenerEnabled = true;

		// Visible
		buttonGoBackForm.setVisible(false);
		textfieldLevel.setVisible(true);
		textfieldPassword.setVisible(false);
		textfieldConfirm.setVisible(false);
		comboBoxAccessLevel.setVisible(false);
		userCreateLabelInfos.setVisible(false);
		passwordLabelInfos.setVisible(false);

		//Editable
		textfieldCPF.setEditable(false);
		textfieldUserName.setEditable(false);
		textfieldLevel.setEditable(false);
		
		// buttons
		buttonShowPassword.setEnabled(true);
		buttonTradePassword.setEnabled(true);
		buttonChangeLevel.setEnabled(true);
		buttonSaveInfos.setEnabled(false);
		buttonDeleteUsers.setEnabled(true);
		buttonCreateusers.setEnabled(true);

	}
	
	private JPanel containerImage() {
		containerComponentsLoginImage = buildMethos.createPanel(new BorderLayout(), 14, 34, colorList.colorWhiteClear, 0, 0, 0, 0);

		containerComponentsLoginImage.add(image, BorderLayout.NORTH);
		return containerComponentsLoginImage;
	}
	
	public static buildUsersConfig getInstance() {
		if (instance == null) {
			instance = new buildUsersConfig();
		}
		return instance;
	}
}

