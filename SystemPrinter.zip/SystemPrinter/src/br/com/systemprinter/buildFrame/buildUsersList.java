package br.com.systemprinter.buildFrame;

import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import br.com.systemprinter.buildMethods.buildMethos;
import br.com.systemprinter.buildMethods.colorList;
import br.com.systemprinter.dao.UserDAO;
import br.com.systemprinter.model.EditingTable;
import br.com.systemprinter.model.UserModel;

public class buildUsersList {
	public static buildUsersList instance;
	
	private JTable tableListUsers;
	private DefaultTableModel dados;
	
	private void listingUsers() throws SQLException {
	    UserDAO dao = new UserDAO();
	    List<UserModel> list = dao.listingDatabaseTableUsers();
	    dados.setNumRows(0);
	    
	    list.forEach(i -> { dados.addRow(new Object[] {
	            i.getUser(),
	            i.getLevel()
	        });
	    });
	}
	
	public JPanel containerMain(JFrame frame) {
		JPanel containerMain = buildMethos.createPanel(new FlowLayout(FlowLayout.LEFT, 10,10), 20, 60, colorList.colorBackgroundWhite, 0, 0, 0, 0);
		containerMain.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, colorList.colorBlack));
		containerMain.add(containerTableListUsers());
		return containerMain;
	}
	
	@SuppressWarnings("serial")
	private JPanel containerTableListUsers() {
	    JPanel containerTableListUsers = buildMethos.createPanel(new BorderLayout(), 19, 58, colorList.colorRed, 0, 0, 0, 0);

	    String[] columnHistoric = {"Usuario", "Acesso"};
	    dados = new DefaultTableModel(columnHistoric, 0) {
			public boolean isCellEditable(int row, int column) {
	            return false;
	        }
	    };
	    
	    try {
			listingUsers();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    
	    tableListUsers = new JTable(dados);
	    tableListUsers.setPreferredScrollableViewportSize(buildMethos.createResponsive(15, 38));

	    EditingTable.setColumnAlignments(tableListUsers, SwingConstants.RIGHT, SwingConstants.CENTER);
	    EditingTable.setResizingAllowed(tableListUsers, false);
	    EditingTable.setReorderingAllowed(tableListUsers, false);
	    tableListUsers.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

	    containerTableListUsers.add(new JScrollPane(tableListUsers), BorderLayout.CENTER);
	    return containerTableListUsers;
	}
	
	public static buildUsersList getInstance() {
		if (instance == null) {
			instance = new buildUsersList();
		}
		return instance;
	}
}
