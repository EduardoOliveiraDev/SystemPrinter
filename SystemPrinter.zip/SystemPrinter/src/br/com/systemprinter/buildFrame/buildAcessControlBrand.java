package br.com.systemprinter.buildFrame;

import java.awt.*;
import java.awt.event.*;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import javax.swing.*;
import javax.swing.text.MaskFormatter;

import br.com.systemprinter.buildMethods.buildMethos;
import br.com.systemprinter.buildMethods.colorList;
import br.com.systemprinter.buildMethods.fontList;
import br.com.systemprinter.dao.UserDAO;
import br.com.systemprinter.dao.UserSessionDAO;
import br.com.systemprinter.view.FrameAcessControlBrand;
import br.com.systemprinter.view.FrameControlBoard;

public class buildAcessControlBrand {
	private UserDAO msDados = new UserDAO();
	private static buildAcessControlBrand instance;  
	private JPanel containerGroupComponentsLogin;
	private JLabel titleText;
	
	private JPanel containerInputForm;
	private JTextField passwordTextField;
	private JPasswordField passwordField;
	
	private JPanel containerRequestForm;
	private JButton buttonShowPassword;
	private JButton buttonSendForm;
	private boolean showPassword = false;
	
	private JLabel errorMensagePassword;
	
	
	private JLabel cpfLabel;
    private JFormattedTextField cpfTextField;

    public buildAcessControlBrand() {
        cpfTextField = createFormattedCPFTextField();
        // Adicione o cpfTextField ao seu painel ou container
    }
	
	private JFormattedTextField createFormattedCPFTextField() {
	    try {
	        MaskFormatter cpfMask = new MaskFormatter("###.###.###-##");
	        cpfMask.setPlaceholderCharacter('_');  // Define um caractere de placeholder se o campo estiver vazio
	        JFormattedTextField cpfTextField = new JFormattedTextField(cpfMask);
	        cpfTextField.setColumns(14);  // Define o tamanho do campo
	        return cpfTextField;
	    } catch (ParseException e) {
	        e.printStackTrace();
	        return new JFormattedTextField();  // Retorna um campo de texto sem formatação em caso de erro
	    }
	}
	
	public JPanel containerCenter(JFrame frame) {
		JPanel mainPanel = buildMethos.createPanel(new FlowLayout(FlowLayout.CENTER), 70, 70, colorList.colorWhiteClear, 0, 0, 0, 0);
		JPanel containerComponentsLogin = buildMethos.createPanel(new BorderLayout(), 55, 60, colorList.colorWhiteClear, 60, 0, 0, 0);
		
		containerComponentsLogin.add(containerComponentsLoginForm(), BorderLayout.WEST);
		containerComponentsLogin.add(containerComponentsLoginImage(), BorderLayout.EAST);
		
		mainPanel.add(containerComponentsLogin);
		return mainPanel;
	}
	
	private JPanel containerComponentsLoginForm() {
		containerGroupComponentsLogin = buildMethos.createPanel(new FlowLayout(), 25, 60, colorList.colorWhiteClear, 100, 0, 0, 0);
		
		titleText = buildMethos.createJLabel("Acessar Painel de Controle", 20, 5, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold22, colorList.colorBlack, "Titulo",0, 0, 0, 0);
		
		// create container and components for input
		containerInputForm = buildMethos.createPanel(new FlowLayout(), 25, 10, colorList.colorWhiteClear, 0, 0, 0, 0);
		cpfLabel= buildMethos.createJLabel("CPF", 20, 4, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold18, colorList.colorTextLightGray, "Insira seu cpf",0, 10, 0, 10);
		cpfTextField = buildMethos.createMaskTextField( "###.###.###-##", '_', 20, 4, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold18, colorList.colorTextLightGray, "Insira seu cpf",0, 10, 0, 10);
		passwordTextField = buildMethos.createTextField("Senha", 20, 4, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold18, colorList.colorTextLightGray, "Insira sua senha",0, 10, 0, 10);
		buttonShowPassword = buildMethos.createJButton("👁", 2.5, 4, colorList.colorBackgroundWhite, SwingConstants.CENTER, fontList.RobotoBold18, colorList.colorTextLightGray, "Mostrar senha",0, 0, 0, 0);
		passwordField = buildMethos.createPasswordField("Senha", 17.2, 4, colorList.colorBackgroundWhite, SwingConstants.LEFT, fontList.RobotoBold18, colorList.colorTextLightGray, "Insira sua senha",0, 10, 0, 10);
		// adding components in container
		containerInputForm.add(cpfLabel);
		containerInputForm.add(cpfTextField);
		containerInputForm.add(passwordTextField);
		cpfTextField.setVisible(false);
		
		// create container and components for request form
		containerRequestForm = buildMethos.createPanel(new BorderLayout(), 20, 3.5, colorList.colorWhiteClear, 0, 0, 0, 0);
		errorMensagePassword = buildMethos.createJLabel("CPF/Senha incorreto.", 13, 2, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold16, colorList.colorWhiteClear, "",0, 0, 0, 0);
		buttonSendForm = buildMethos.createJButton("Acessar", 7, 3, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold18, colorList.colorWhiteClear, "Enviar",0, 0, 0, 0);
		// adding components in container
		containerRequestForm.add(errorMensagePassword, BorderLayout.WEST);
		containerRequestForm.add(buttonSendForm, BorderLayout.EAST);

		containerComponentsLoginFormFunctions();
		containerGroupComponentsLogin.add(titleText);
		containerGroupComponentsLogin.add(containerInputForm);
		containerGroupComponentsLogin.add(containerRequestForm);
		
		return containerGroupComponentsLogin;
	}
	
	private void containerComponentsLoginFormFunctions() {
		
		cpfLabel.addMouseListener(new  MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				cpfTextField.setVisible(true);
				cpfLabel.setVisible(false);
				cpfTextField.requestFocus();
			}
		});
		
		cpfTextField.addFocusListener(new FocusAdapter() {
			public void focusLost(FocusEvent e) {
				if (cpfTextField.getText().equals("___.___.___-__")) {
					cpfTextField.setVisible(false);
					cpfLabel.setVisible(true);
				}
				
			}
		});
	
		passwordTextField.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
				if (passwordTextField.getText().equalsIgnoreCase("Senha") || passwordTextField.getText().isEmpty()) {
					tradeTextForPassword();
					reloadFrame();
				}
			}
		});
		
		passwordField.addFocusListener(new FocusAdapter() {
			public void focusLost(FocusEvent e) {
				if (new String(passwordField.getPassword()).isEmpty()) {
					passwordTextField.setPreferredSize(buildMethos.createResponsive(20, 4));
					passwordTextField.setText("Senha");
					tradePasswordForText();
					reloadFrame();
				}
			}
		});
	
		if (passwordTextField.getText().isEmpty() || new String(passwordField.getPassword()).isEmpty()) {
			buttonShowPassword.setEnabled(false);
		} else {
			buttonShowPassword.setEnabled(true);
		}
		
		buttonShowPassword.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (showPassword) {
					encryptedPassword();
					reloadFrame();
				} else {
					deencryptedPassword();
					reloadFrame();
				}
			}
		});
		
		buttonSendForm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					verifyLoginAcess();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
	
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(e -> {
            if (e.getID() == KeyEvent.KEY_PRESSED && e.getKeyCode() == KeyEvent.VK_ENTER) {
                try {
					verifyLoginAcess();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
            }
            return false;
        });
	}
	
	private void verifyLoginAcess() throws Exception {
		accessDeveloper();
	    
		if (buttonSendForm != null) {
		    String cpf = cpfTextField.getText().replace(".", "").replace("-", "");
		    String password;
		    
		    // get password
		    if (!showPassword) {
		        password = new String(passwordField.getPassword());
		    } else {
		        password = passwordTextField.getText();
		    }
		    
		    List<String> blockedAccessLevels = Arrays.asList("INATIVO");
		    if (msDados.isValidUser(cpf, password, blockedAccessLevels)) {
		        FrameControlBoard frame = new FrameControlBoard();
		        frame.setVisible(true);
		        
		        FrameAcessControlBrand.getInstance().getFrame().dispose();
		        clearForm();
		        errorMensagePassword.setForeground(colorList.colorWhiteClear);
		    } else {
		        errorMensagePassword.setForeground(colorList.colorRed);
		        clearForm();
		    }
		} else {
		    System.out.println("Componente buttonSendForm não foi iniciado com sucesso!");
		}
	}
	
	private void accessDeveloper() {
//		if (cpfTextField.getText().replace(".", "").replace("-", "").replace("_", "").equals("00000000000") &&
//			new String(passwordField.getPassword()).equalsIgnoreCase("uxpt34cfah")) {
//			UserSessionDAO.getInstance().setUserSession(0, "00000000000", "Developer", "Developer");
//	        FrameControlBoard frame = new FrameControlBoard();
//	        frame.setVisible(true);
//	        FrameAcessControlBrand.getInstance().getFrame().dispose();
//		}
		
		// Test Environment
		if (cpfTextField.getText().replace(".", "").replace("-", "").replace("_", "").equalsIgnoreCase("1") &&
		new String(passwordField.getPassword()).equalsIgnoreCase("1")) {
		UserSessionDAO.getInstance().setUserSession(0, "12345678900", "Developer", "Developer");
        FrameControlBoard frame = new FrameControlBoard();
        frame.setVisible(true);
        FrameAcessControlBrand.getInstance().getFrame().dispose();
        
		}
	}
	
	private void clearForm() {
		cpfTextField.setText("");
		cpfTextField.setVisible(false);
		cpfLabel.setVisible(true);
		
		if (showPassword) {
			tradePasswordForText();
			passwordTextField.setPreferredSize(buildMethos.createResponsive(20, 4));
			buildMethos.setPlaceholder(passwordTextField, "Senha");
			passwordField.setText("");
			showPassword = false;
			reloadFrame();
		} else {
			tradePasswordForText();
			passwordField.setText("");
			buildMethos.setPlaceholder(passwordTextField, "Senha");
			showPassword = false;
		}

		titleText.requestFocus();
	}
	
	private void tradeTextForPassword() {
		containerInputForm.remove(passwordTextField);
		containerInputForm.add(passwordField);
		containerInputForm.add(buttonShowPassword);
		passwordField.requestFocus();
	}
	
	private void tradePasswordForText() {
		containerInputForm.add(passwordTextField);
		containerInputForm.remove(passwordField);
		containerInputForm.remove(buttonShowPassword);
	}
	
	private void encryptedPassword() {
		if(!passwordTextField.getText().equalsIgnoreCase("Senha") && !passwordTextField.getText().isEmpty()) {
			showPassword = false;
			tradeTextForPassword();
			passwordField.setText(passwordTextField.getText());
			reloadFrame();			
		} else if(!new String(passwordField.getPassword()).equalsIgnoreCase("Senha") && !new String(passwordField.getPassword()).isEmpty()) {
			deencryptedPassword();
			reloadFrame();
		}
	}
	
	private void deencryptedPassword() {
		showPassword = true;
		tradePasswordForText();
		passwordTextField.setText(new String(passwordField.getPassword()));
		passwordTextField.setPreferredSize(buildMethos.createResponsive(17.2, 4));
		containerInputForm.add(buttonShowPassword);
		reloadFrame();
	}
	
	private void reloadFrame() {
		containerGroupComponentsLogin.repaint();
		containerGroupComponentsLogin.updateUI();
	}
	
	private JPanel containerComponentsLoginImage() {
	    JPanel containerComponentsLoginImage = buildMethos.createPanel(new BorderLayout(), 30, 60, Color.WHITE, 0, 0, 0, 0);
	    JLabel imageLabel = buildMethos.createLabelImage("../icons/ImageLoginPerson.jpg", 25, 50);
	    
	    containerComponentsLoginImage.add(imageLabel, BorderLayout.EAST);
	    return containerComponentsLoginImage;
	}
	
    public static buildAcessControlBrand getInstance() {
        if (instance == null) {
            instance = new buildAcessControlBrand();
        }
        return instance;
    }
	
}
