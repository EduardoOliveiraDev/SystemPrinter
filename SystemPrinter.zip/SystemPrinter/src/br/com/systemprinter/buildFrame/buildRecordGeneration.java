package br.com.systemprinter.buildFrame;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.toedter.calendar.JDateChooser;

import br.com.systemprinter.buildMethods.buildMethos;
import br.com.systemprinter.buildMethods.colorList;
import br.com.systemprinter.buildMethods.fontList;
import br.com.systemprinter.dao.UserDAO;
import br.com.systemprinter.utils.ReportServiceUtils;

public class buildRecordGeneration {
	public static buildRecordGeneration instance;
	private JDateChooser dateChooserMin;
	private JDateChooser dateChooserMax;
	private JComboBox<String> comboBoxTypesGeneration;
	private JComboBox<String> comboUsers;
	private JTextField textfieldPrice;
	private JButton buttonGeneration;
	
	public JPanel containerMain(JFrame frame) {
		JPanel contentPane = buildMethos.createPanel(new BorderLayout(), 20, 30, colorList.colorWhiteClear, 15, 15, 15, 15);
		
		contentPane.add(containerForm(frame), BorderLayout.CENTER);
		contentPane.add(containerFooter(), BorderLayout.PAGE_END);
		return contentPane;
	}

	@SuppressWarnings("unchecked")
	private JPanel containerForm(JFrame frame) {
		JPanel panelForm = buildMethos.createPanel(new FlowLayout(FlowLayout.LEFT, 10,10), 20, 20, colorList.colorWhiteClear, 0, 0, 0, 0);
		
		// Date minimum
		JLabel labelDateMinimum = buildMethos.createJLabel("Data inicial", 11, 3, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold16, colorList.colorBlack, "Descrição", 0, 0, 0, 0);
		dateChooserMin = buildMethos.createCalendar(6, 3, colorList.colorWhiteClear, fontList.RobotoPlain16, colorList.colorBlack, "Insira um data",0, 0, 0, 0);
		buildMethos.editCalendar(dateChooserMin, colorList.colorWhiteClear, false, colorList.colorBlack, colorList.colorBlack);

		// Date maximum
		JLabel labelDateMaximum = buildMethos.createJLabel("Data final", 11, 3, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold16, colorList.colorBlack, "Descrição", 0, 0, 0, 0);
		dateChooserMax = buildMethos.createCalendar(6, 3, colorList.colorWhiteClear, fontList.RobotoPlain16, colorList.colorBlack, "Insira um data",0, 0, 0, 0);
		buildMethos.editCalendar(dateChooserMax, colorList.colorWhiteClear, false, colorList.colorBlack, colorList.colorBlack);
		
		// Type generation
		JLabel labelTypeGeneration = buildMethos.createJLabel("Tipo de geração", 11, 3, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold16, colorList.colorBlack, "Descrição", 0, 0, 0, 0);
		comboBoxTypesGeneration = (JComboBox<String>) buildMethos.createComboBox(6, 3, colorList.colorWhiteClear, fontList.RobotoPlain16, colorList.colorBlack, 0, 0, 0, 0);
		comboBoxTypesGeneration.addItem(""); 
		comboBoxTypesGeneration.addItem("PDF"); 
		comboBoxTypesGeneration.addItem("Excel");
		
        JLabel labelSelectedUsers = buildMethos.createJLabel("Filtro de Usuarios", 11, 3, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold16, colorList.colorBlack, "Descrição", 0, 0, 0, 0);
        comboUsers = (JComboBox<String>) buildMethos.createComboBox(6, 3, colorList.colorWhiteClear, fontList.RobotoBold16, colorList.colorBlack, 0, 0, 0, 0);
        comboUsers.addItem("TODOS");
		comboUsers.setMaximumRowCount(10);
        
		JLabel labelPriceToPage = buildMethos.createJLabel("Valor por pagina", 11, 3, colorList.colorWhiteClear, SwingConstants.LEFT, fontList.RobotoBold16, colorList.colorBlack, "Descrição", 0, 0, 0, 0);
		textfieldPrice = buildMethos.createTextField("R$  0.00", 6, 3, colorList.colorBackgroundWhite, SwingConstants.RIGHT, fontList.RobotoBold18, colorList.colorBlack, "Insira um preço",0, 20, 0, 20);
		buildMethos.setPlaceholder(textfieldPrice, "R$ 0.00");
		
		containerFormFunctions();
		panelForm.add(labelDateMinimum);
		panelForm.add(dateChooserMin);
		panelForm.add(labelDateMaximum);
		panelForm.add(dateChooserMax);
		panelForm.add(labelTypeGeneration);
		panelForm.add(comboBoxTypesGeneration);
		panelForm.add(labelSelectedUsers);
		panelForm.add(comboUsers);
		panelForm.add(labelPriceToPage);
		panelForm.add(textfieldPrice);
		return panelForm;
	}
	
	private void loadUsers(Date startDate, Date endDate) {
	    UserDAO userDAO = new UserDAO();
	    try {
	        if (!"Excel".equals(comboBoxTypesGeneration.getSelectedItem().toString())) {
	            // Retorna uma lista de Strings com nomes de usuários
	            List<String> userNames = userDAO.getUsersByDateRange(startDate, endDate);
	            comboUsers.removeAllItems();
	            
	            if (userNames.isEmpty()) {
	                comboUsers.addItem("Sem usuários");
	                buttonGeneration.setEnabled(false);
	            } else {
	                comboUsers.addItem("TODOS");
	                for (String userName : userNames) {
	                    // Adiciona um item com o nome do usuário, você precisa obter o CPF de outra forma
	                    // Aqui estamos assumindo que `getCPFByUserName` é um método que você tem ou precisa criar
	                    String cpf = userDAO.getCPFByUserName(userName);
	                    comboUsers.addItem(userName + " - " + cpf);
	                }
	                buttonGeneration.setEnabled(true);
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Erro ao carregar usuários.", "Erro", JOptionPane.ERROR_MESSAGE);
	    }
	}

	private void containerFormFunctions() {
	    dateChooserMin.addPropertyChangeListener(new PropertyChangeListener() {
	        public void propertyChange(PropertyChangeEvent evt) {
	            if ("date".equals(evt.getPropertyName())) {
	                Date selectedDate = dateChooserMin.getDate();
	                Date endDate = dateChooserMax.getDate();
	                if (selectedDate != null && endDate != null) {
	                    verifyDate();
	                }
	            }
	        }
	    });
	    
	    dateChooserMax.addPropertyChangeListener(new PropertyChangeListener() {
	        public void propertyChange(PropertyChangeEvent evt) {
	            if ("date".equals(evt.getPropertyName())) {
	                Date selectedDate = dateChooserMin.getDate();
	                Date endDate = dateChooserMax.getDate();
	                if (selectedDate != null && endDate != null) {
	                    verifyDate();
	                }
	            }
	        }
	    });

	    comboBoxTypesGeneration.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            String selectedType = (String) comboBoxTypesGeneration.getSelectedItem();
	            Date startDate = dateChooserMin.getDate();
	            Date endDate = dateChooserMax.getDate();

	            if ("Excel".equals(selectedType)) {
	                comboUsers.removeAllItems();
	                comboUsers.addItem("TODOS");
	                comboUsers.setEnabled(false); // Disable the user selection
	            } else if ("PDF".equals(selectedType)) {
	                comboUsers.setEnabled(true); // Enable the user selection
	                if (startDate != null && endDate != null) {
	                    loadUsers(startDate, endDate); // Re-load users based on date range
	                }
	            }
	        }
	    });
	}
	
	private JPanel containerFooter() {
		JPanel panelFooter = buildMethos.createPanel(new FlowLayout(FlowLayout.RIGHT, 10,0), 20, 3.5, colorList.colorWhiteClear, 0, 0, 0, 0);
		buttonGeneration = buildMethos.createJButton("Gerar", 4.5, 3.5, colorList.colorCyanTiber, SwingConstants.CENTER, fontList.RobotoBold14, colorList.colorWhiteClear, "Salvar", 0, 0, 0, 0);
		buttonGeneration.setEnabled(false);
		buttonGeneration.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				verifyForm();
			}
		});
		
		
		
		panelFooter.add(buttonGeneration);
		return panelFooter;
	}
	
	private void verifyDate() {
	    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	    Date selectedDateMin = dateChooserMin.getDate();
	    Date selectedDateMax = dateChooserMax.getDate();
	    String reportType = comboBoxTypesGeneration.getSelectedItem().toString();
	    
	    String formattedDateMin = selectedDateMin != null ? sdf.format(selectedDateMin) : null;
	    String formattedDateMax = selectedDateMax != null ? sdf.format(selectedDateMax) : null;
	
	    if (formattedDateMin != null && formattedDateMax != null && selectedDateMin.after(selectedDateMax)) {
	        JOptionPane.showMessageDialog(null, "A data mínima não pode ser maior que a data máxima.", "Erro", JOptionPane.ERROR_MESSAGE);
	        dateChooserMin.setDate(null);
	        dateChooserMax.setDate(null);
	    } else {
	        if (!"Excel".equals(reportType)) {
	            loadUsers(selectedDateMin, selectedDateMax);
	        }
	    }
	}
	
	public void verifyForm() {
	    double price = 0;
	    try {
	    	price = Double.parseDouble(textfieldPrice.getText().replace(',', '.'));
		} catch (NumberFormatException  e) {
			JOptionPane.showMessageDialog(null, "Erro ao converter o preço", "Erro", JOptionPane.ERROR_MESSAGE);
		}
	    
	    if (comboBoxTypesGeneration.getSelectedItem() == null || dateChooserMin.getDate() == null || dateChooserMax.getDate() == null || textfieldPrice.getText().contentEquals("R$ 0.00") || price <= 0) {
	        JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo vazio", JOptionPane.INFORMATION_MESSAGE);
	        return;
	    }
	    
	    Date startDate = dateChooserMin.getDate();
	    Date endDate = dateChooserMax.getDate();
	    String reportType = comboBoxTypesGeneration.getSelectedItem().toString();
	    String selectedUsers = comboUsers.getSelectedItem().toString();

	    if (!reportType.isEmpty() && startDate != null && endDate != null && price > 0) {
	        if (reportType.equals("PDF")) {
	            ReportServiceUtils.generatePDFReport(formatDateForMySQL(startDate), formatDateForMySQL(endDate), selectedUsers, price);
	        } else if (reportType.equals("Excel")) {
	            ReportServiceUtils.generateExcelReport(formatDateForMySQL(startDate), formatDateForMySQL(endDate));
	        }
	    }
	}
	
	private java.sql.Timestamp formatDateForMySQL(Date date) {
	    return new java.sql.Timestamp(date.getTime());
	}

	
	public static buildRecordGeneration getInstance() {
		if (instance == null) {
			instance = new buildRecordGeneration();
		}
		return instance;
	}
}
