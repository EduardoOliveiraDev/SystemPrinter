package br.com.systemprinter.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;

import br.com.systemprinter.PrinterUtils.PrinterBlockedAccessNative;
import br.com.systemprinter.buildComponents.buildNavBar;
import br.com.systemprinter.buildFrame.buildAcessControlBrand;

@SuppressWarnings("serial")
public class FrameAcessControlBrand extends JFrame {
	private buildNavBar navBar = new buildNavBar();
	private buildAcessControlBrand builderPanel = buildAcessControlBrand.getInstance();  
	
	private JPanel contentPane;
	private static FrameAcessControlBrand instance;

	public FrameAcessControlBrand() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Painel de acesso");
        setResizable(false);
        setUndecorated(true);

        contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);
        BuildFrame();

        pack();
        setLocationRelativeTo(null);
        instance = this;
	}
	
	
	
	public void BuildFrame() {
		PrinterBlockedAccessNative.stopSpooler();
		contentPane.add(navBar.containerMain(this, "Painel de Acesso", 80), BorderLayout.NORTH);
        contentPane.add(builderPanel.containerCenter(this), BorderLayout.CENTER);
	}
	
	public static FrameAcessControlBrand getInstance() {
		if (instance == null) {
			instance = new FrameAcessControlBrand();
		}
		return instance;
	}
	
	public JFrame getFrame() {
		return this;
	}
	
	public boolean getVisible() {
		return isVisible();
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameAcessControlBrand frame = new FrameAcessControlBrand();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}

