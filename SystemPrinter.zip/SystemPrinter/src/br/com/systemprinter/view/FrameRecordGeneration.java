package br.com.systemprinter.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import br.com.systemprinter.buildComponents.buildNavBar;
import br.com.systemprinter.buildFrame.buildRecordGeneration;

@SuppressWarnings("serial")
public class FrameRecordGeneration extends JFrame {
	private buildNavBar navBar = new buildNavBar();
	private buildRecordGeneration builderPanel = buildRecordGeneration.getInstance();  
	
	private JPanel contentPane;
	public static FrameRecordGeneration instance;

	public FrameRecordGeneration() {
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Geração de relatorio");
        setResizable(false);
        setUndecorated(true);
		
		contentPane = new JPanel(new BorderLayout());
		setContentPane(contentPane);
		buildFrame();
		
        pack();
        setLocationRelativeTo(null);
		instance = this;
	}

	private void buildFrame() {
		contentPane.add(navBar.containerMain(this, "Geração de relatorio manual", 20), BorderLayout.NORTH);
		contentPane.add(builderPanel.containerMain(this));
	}
	
	/*
	 * 
	*/
	public static FrameRecordGeneration getInstance() {
		if (instance == null) {
			instance = new FrameRecordGeneration();
		}
		return instance;
	}
	
	public JFrame getFrame() {
		return this;
	}
	
	public boolean getVisible() {
		return isVisible();
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameRecordGeneration frame = new FrameRecordGeneration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
