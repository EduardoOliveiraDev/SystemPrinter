package br.com.systemprinter.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import br.com.systemprinter.buildComponents.buildNavBar;
import br.com.systemprinter.buildFrame.buildUsersList;

@SuppressWarnings("serial")
public class FrameUsersList extends JFrame {
	private buildNavBar navBar = new buildNavBar();
	private buildUsersList builderPanel = buildUsersList.getInstance(); 
	
	private static FrameUsersList instance;
	private JPanel contentPane;
	public FrameUsersList() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Lista de Usuarios");
        setResizable(false);
        setUndecorated(true);
		
		contentPane = new JPanel(new BorderLayout());
		setContentPane(contentPane);
		buildFrame();
		
		
        pack();
        setLocationRelativeTo(null);
        instance = this;
        
	}

	
	private void buildFrame() {
		contentPane.add(navBar.containerMain(this, "Lista de usuarios", 10), BorderLayout.NORTH);
		contentPane.add(builderPanel.containerMain(this), BorderLayout.CENTER);
	}
	
	public static FrameUsersList getInstance() {
		if (instance == null) {
			instance = new FrameUsersList();
		}
		return instance;
	}
	
	public JFrame getFrame() {
		return this;
	}
	
	public boolean getVisible() {
		return isVisible();
	}
	
 	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameUsersList frame = new FrameUsersList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
