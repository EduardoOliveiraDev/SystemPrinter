package br.com.systemprinter.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import br.com.systemprinter.PrinterUtils.PrinterBlockedAccessNative;
import br.com.systemprinter.buildComponents.buildNavBar;
import br.com.systemprinter.buildFrame.buildControlBoard;
import br.com.systemprinter.dao.UserSessionDAO;

@SuppressWarnings("serial")
public class FrameControlBoard extends JFrame {
	private buildNavBar navBar = new buildNavBar();
	private buildControlBoard builderPanel = buildControlBoard.getInstance();  
	
	private JPanel contentPane;
	private static FrameControlBoard instance;

	public FrameControlBoard() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Painel de controle");
        setResizable(false);
        setUndecorated(true);

        contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);
        buildFrame();

        pack();
        setLocationRelativeTo(null);
        instance = this;
	}

	public void buildFrame() {
		PrinterBlockedAccessNative.startSpooler();
		String user = UserSessionDAO.getInstance().getCurrentUser();
		contentPane.add(navBar.containerMain(this, "Painel de Controle - " + user, 80), BorderLayout.NORTH);
        contentPane.add(builderPanel.containerCenter(this), BorderLayout.CENTER);
	}
	
	/*
	 * 
	*/
	public static FrameControlBoard getInstance() {
		if (instance == null) {
			instance = new FrameControlBoard();
		}
		return instance;
	}
	
	public JFrame getFrame() {
		return this;
	}
	
	public boolean getVisible() {
		return isVisible();
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameControlBoard frame = new FrameControlBoard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
