package br.com.systemprinter.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;

import br.com.systemprinter.buildComponents.buildNavBar;
import br.com.systemprinter.buildFrame.buildUsersConfig;

@SuppressWarnings("serial")
public class FrameUsersConfig extends JFrame {
	private buildNavBar navBar = new buildNavBar();
	private buildUsersConfig builderPanel = buildUsersConfig.getInstance();  
	
	private JPanel contentPane;
	private static FrameUsersConfig instance;

	public FrameUsersConfig() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Configurações de usuarios");
        setResizable(false);
        setUndecorated(true);
		
		contentPane = new JPanel(new BorderLayout());
		setContentPane(contentPane);
		buildFrame();
		
        addWindowListener(new WindowAdapter() {
            public void windowActivated(WindowEvent evt) {
                try {
                    builderPanel.listingUsers();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            
        });
		
        pack();
        setLocationRelativeTo(null);
        instance = this;
	}

	private void buildFrame() {
		contentPane.add(navBar.containerMain(this, "Configurações de usuario", 50), BorderLayout.NORTH);
		contentPane.add(builderPanel.containerMain(this), BorderLayout.CENTER);
	}
	
	public static FrameUsersConfig getInstance() {
		if (instance == null) {
			instance = new FrameUsersConfig();
		}
		return instance;
	}
	
	public JFrame getFrame() {
		return this;
	}
	
	public boolean getVisible() {
		return isVisible();
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameUsersConfig frame = new FrameUsersConfig();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
