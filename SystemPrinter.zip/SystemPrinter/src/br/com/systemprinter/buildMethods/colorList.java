package br.com.systemprinter.buildMethods;

import java.awt.*;

public class colorList {

	// Method
	private static Color createColor(int red, int green, int blue) {
		return new Color(red, green, blue);
	}
	
	// backgrounds
	public static Color colorBackgroundWhite = createColor(230, 230, 230);
	
	// text colors
	public static Color colorTextLightGray = createColor(100, 100, 100);
	
	// commons colors
	public static Color colorWhiteClear = createColor(255, 255, 255);
	public static Color colorBlack = createColor(0, 0, 0);
	public static Color colorGray = createColor(80, 80, 80);
	public static Color colorLightGray = createColor(238, 238, 238);
	public static Color colorRed = createColor(255, 0, 0);
	public static Color colorGreen = createColor(0, 255, 0);
	public static Color colorDarkGreen = createColor(50, 205, 50);
	public static Color colorCyanTiber = createColor(4, 35, 35);
}
