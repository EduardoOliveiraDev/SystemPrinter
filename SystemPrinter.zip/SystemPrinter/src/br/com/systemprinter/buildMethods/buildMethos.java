package br.com.systemprinter.buildMethods;

import java.awt.*;
import java.net.URL;
import java.text.ParseException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;

public class buildMethos {

	public static GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
	public static Rectangle bounds = env.getMaximumWindowBounds();

	public static JPanel createPanel(LayoutManager layout, double width, double height, Color backgroundColor, int top, int left, int bottom, int right) {
		JPanel panel = new JPanel();
		panel.setLayout(layout);
		panel.setPreferredSize(createResponsive(width, height));
		panel.setBackground(backgroundColor);
		panel.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, backgroundColor));
		return panel;
	}

	public static JMenuBar createJMenuBar(LayoutManager layout, double width, double height, Color backgroundColor) {
		JMenuBar menuBar = new JMenuBar();
		menuBar.setLayout(layout);
		menuBar.setPreferredSize(createResponsive(width, height));
		menuBar.setBackground(backgroundColor);
		menuBar.setBorder(BorderFactory.createEmptyBorder());
		return menuBar;
	}
	
	public static JMenu createJMenuButton(String text, double width, double height, Color backgroundColor, Font FontType, Color FontColor) {
		JMenu menu = new JMenu();
		menu.setText(text);
		menu.setPreferredSize(createResponsive(width, height));
		menu.setBackground(backgroundColor);
		menu.setBorder(BorderFactory.createEmptyBorder());
		menu.setForeground(FontColor);
		menu.setFont(FontType);
		return menu;
	}
	
	public static JMenuItem createJMenuItemPopUp(String text, double width, double height, Color backgroundColor, Font FontType, Color FontColor) {
		JMenuItem menuItem = new JMenuItem();
		menuItem.setText(text);
		menuItem.setPreferredSize(createResponsive(width, height));
		menuItem.setBackground(backgroundColor);
		menuItem.setBorder(BorderFactory.createEmptyBorder());
		menuItem.setForeground(FontColor);
		menuItem.setFont(FontType);
		return menuItem;
	}
	
    public static JSpinner createSpinner(double width, double height, Color backgroundColor, Font fontFamily, Color fontColor) {
        JSpinner jSpinner = new JSpinner();
        jSpinner.setOpaque(true);
        jSpinner.setBorder(new EmptyBorder(0, 0, 0, 0));
        jSpinner.setPreferredSize(createResponsive(width, height));
        
        JComponent editor = jSpinner.getEditor();
        if (editor instanceof JSpinner.DefaultEditor) {
            JTextField textField = ((JSpinner.DefaultEditor) editor).getTextField();
            textField.setBackground(backgroundColor);
            textField.setForeground(fontColor);
            textField.setFont(fontFamily);
        }
        
        return jSpinner;
    }
	
 	public static JButton createJButton(String text, double width, double height, Color backgroundColor, int Position, Font FontType, Color FontColor, String Description, int top, int left, int bottom, int right) {
		JButton button = new JButton();
		button.setFocusPainted(false);
		button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		button.setText(text);
		button.setPreferredSize(createResponsive(width, height));
		button.setBackground(backgroundColor);
		button.setHorizontalAlignment(Position);
		button.setFont(FontType);
		button.setForeground(FontColor);
		button.setToolTipText(Description);
		button.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, backgroundColor));
		return button;
	}

	public static JLabel createJLabel(String text, double width, double height, Color backgroundColor, int Position, Font FontType, Color FontColor, String Description, int top, int left, int bottom, int right) {
		JLabel label = new JLabel();
		label.setOpaque(true);
		label.setText(text);
		label.setPreferredSize(createResponsive(width, height));
		label.setBackground(backgroundColor);
		label.setHorizontalAlignment(Position);
		label.setFont(FontType);
		label.setForeground(FontColor);
		label.setToolTipText(Description);
		label.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, backgroundColor));
		return label;
	}

    public static JComboBox<?> createComboBox(double width, double height, Color BackgroundColor, Font FontFamiliy, Color FontColor, int top, int right, int bottom, int left) {
        JComboBox<?> jComboBox = new JComboBox<>();
        jComboBox.setForeground(FontColor);
        jComboBox.setBackground(BackgroundColor);
        jComboBox.setOpaque(true);
        jComboBox.setFont(FontFamiliy);
        jComboBox.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, BackgroundColor));
        jComboBox.setPreferredSize(createResponsive(width, height));
        jComboBox.setMaximumRowCount(4);
        jComboBox.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        return jComboBox;
    }
	
	public static JTextField createTextField(String text, double width, double height, Color backgroundColor, int Position, Font FontType, Color FontColor, String Description,int top, int left, int bottom, int right) {
		JTextField JTextField = new JTextField();
		JTextField.setText(text);
		JTextField.setHorizontalAlignment(Position);
		JTextField.setForeground(FontColor);
		JTextField.setBackground(backgroundColor);
		JTextField.setOpaque(true);
		JTextField.setFont(FontType);
		JTextField.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, backgroundColor));
		JTextField.setToolTipText(Description);
		JTextField.setPreferredSize(createResponsive(width, height));
		return JTextField;
	}
	
	public static JFormattedTextField  createMaskTextField(String maskFormat, char placeHolder, double width, double height, Color backgroundColor, int Position, Font FontType, Color FontColor, String Description,int top, int left, int bottom, int right) {
        MaskFormatter Mask = null;
		try {
			Mask = new MaskFormatter(maskFormat);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
        Mask.setPlaceholderCharacter(placeHolder);
		
		JFormattedTextField  JFormattedTextField  = new JFormattedTextField(Mask);
		JFormattedTextField.setHorizontalAlignment(Position);
		JFormattedTextField.setForeground(FontColor);
		JFormattedTextField.setBackground(backgroundColor);
		JFormattedTextField.setOpaque(true);
		JFormattedTextField.setFont(FontType);
		JFormattedTextField.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, backgroundColor));
		JFormattedTextField.setToolTipText(Description);
		JFormattedTextField.setPreferredSize(createResponsive(width, height));
		JFormattedTextField.setFocusLostBehavior(javax.swing.JFormattedTextField.PERSIST);

		return JFormattedTextField;
	}

	public static JPasswordField createPasswordField(String text, double width, double height, Color backgroundColor, int Position, Font FontType, Color FontColor, String Description,int top, int left, int bottom, int right) {
		JPasswordField JPasswordField = new JPasswordField();
		JPasswordField.setHorizontalAlignment(Position);
		JPasswordField.setForeground(FontColor);
		JPasswordField.setBackground(backgroundColor);
		JPasswordField.setOpaque(true);
		JPasswordField.setFont(FontType);
		JPasswordField.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, backgroundColor));
		JPasswordField.setPreferredSize(createResponsive(width, height));
		JPasswordField.setToolTipText(Description);
		return JPasswordField;
	}

    public static void showMessageTemp(String message, String title, int messageType, int seconds) {
        Timer timer = new Timer(seconds * 1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Fecha o JOptionPane
                Window[] windows = Window.getWindows();
                for (Window window : windows) {
                    if (window instanceof JDialog) {
                        window.dispose();
                    }
                }
            }
        });

        timer.setRepeats(false);
        timer.start();

        JOptionPane.showMessageDialog(null, message, title, messageType);
    }
	
    public static void setPlaceholder(JTextField textField, String placeholder) {
        if (!textField.isEnabled() || !textField.isEditable()) {
            return;
        }

        textField.setText(placeholder);
        textField.setForeground(colorList.colorTextLightGray);

        textField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (textField.isEnabled() && textField.isEditable()) {
                    if (textField.getText().equals(placeholder)) {
                        textField.setText("");
                        textField.setForeground(colorList.colorBlack);
                    }
                }
            }

            public void focusLost(FocusEvent e) {
                if (textField.isEnabled() && textField.isEditable()) {
                    if (textField.getText().isEmpty()) {
                        textField.setText(placeholder);
                        textField.setForeground(colorList.colorTextLightGray);
                    }
                }
            }
        });
    }
    
    public static String maskPassword(String password) {
        return "*".repeat(password.length());
    }
    
	public static JDateChooser createCalendar(double width, double height, Color backgroundColor, Font FontType, Color FontColor, String Description, int top, int left, int bottom, int right) {
		JDateChooser calendar = new JDateChooser();
		calendar.setDateFormatString("dd/MM/yyyy");
		calendar.setForeground(FontColor);
		calendar.setBackground(backgroundColor);
		calendar.setFont(FontType);
		calendar.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, backgroundColor));
		calendar.setPreferredSize(createResponsive(width, height));
		calendar.setToolTipText(Description);
		return calendar;
	}
	
	public static JCalendar editCalendar(JDateChooser dateChooser, Color backgroundColor, boolean WeekVisible, Color colorSunday, Color colorWeek ) {
        JCalendar calendar = dateChooser.getJCalendar();
        calendar.setDecorationBackgroundColor(backgroundColor);
        calendar.setWeekOfYearVisible(WeekVisible);
        calendar.setSundayForeground(colorSunday); // marca domingo
        calendar.setWeekdayForeground(colorWeek); // resto da semana
        return calendar;
	}
	
	public static JLabel createLabelImage(String locate, double widthScreenPercentual, double heightScreenPercentual) {
		Dimension dimension = createResponsive(widthScreenPercentual, heightScreenPercentual);
		int width = (int) dimension.getWidth();
		int height = (int) dimension.getHeight();
		URL resource = buildMethos.class.getResource(locate);

		if (resource == null) {
			System.err.println("Erro ao carregar o recurso: " + locate);
			return new JLabel("Imagem não encontrada");
		}

		ImageIcon icon = new ImageIcon(resource);
		if (icon.getImageLoadStatus() != MediaTracker.COMPLETE) {
			System.err.println("Erro ao carregar a imagem: " + locate);
			return new JLabel("Imagem não encontrada");
		}

		Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
		ImageIcon resizedIcon = new ImageIcon(img);
		JLabel label = new JLabel(resizedIcon);
		return label;
	}
	
	public static ImageIcon createImageIcon(String path, double widthScreenPercentual, double heightScreenPercentual) {
	    Dimension dimension = createResponsive(widthScreenPercentual, heightScreenPercentual);
	    int width = (int) dimension.getWidth();
	    int height = (int) dimension.getHeight();
	    
	    // Ajustar o caminho do recurso
	    URL resource = buildMethos.class.getResource(path);
	    
	    if (resource == null) {
	        System.err.println("Erro ao carregar o recurso: " + path);
	        return new ImageIcon(); // Retorna uma imagem vazia como fallback
	    }
	    
	    ImageIcon icon = new ImageIcon(resource);
	    if (icon.getImageLoadStatus() != MediaTracker.COMPLETE) {
	        System.err.println("Erro ao carregar a Icon: " + path);
	        return new ImageIcon(); // Retorna uma imagem vazia como fallback
	    }
	    
	    Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
	    return new ImageIcon(img);
	}
	
	public static Dimension createResponsive(double widthScreenPercentual, double heightScreenPercentual) {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int widthScreen = (int) (screenSize.width * (widthScreenPercentual/100));
		int heightScreen = (int) (screenSize.height * (heightScreenPercentual/100));
		return new Dimension(widthScreen, heightScreen);
	}

}
