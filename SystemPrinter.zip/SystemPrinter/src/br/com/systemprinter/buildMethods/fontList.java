package br.com.systemprinter.buildMethods;

import java.awt.Font;

public class fontList {

	private static Font createFont(String FontName, int FontStyle, int FontSize) {
		return new Font(FontName, FontStyle, FontSize);
	}
	
	public static Font RobotoBold12 = createFont("Roboto", Font.BOLD, 12);
	public static Font RobotoBold14 = createFont("Roboto", Font.BOLD, 14);
	public static Font RobotoBold16 = createFont("Roboto", Font.BOLD, 16);
	public static Font RobotoBold18 = createFont("Roboto", Font.BOLD, 18);
	public static Font RobotoBold20 = createFont("Roboto", Font.BOLD, 20);
	public static Font RobotoBold22 = createFont("Roboto", Font.BOLD, 22);
	
	public static Font RobotoPlain12 = createFont("Roboto", Font.PLAIN, 12);
	public static Font RobotoPlain14 = createFont("Roboto", Font.PLAIN, 14);
	public static Font RobotoPlain16 = createFont("Roboto", Font.PLAIN, 16);

	
	public static Font RobotoItalic12 = createFont("Roboto", Font.ITALIC, 12);
	public static Font RobotoItalic14 = createFont("Roboto", Font.ITALIC, 14);
	public static Font RobotoItalic16 = createFont("Roboto", Font.ITALIC, 16);
	public static Font RobotoItalic18 = createFont("Roboto", Font.ITALIC, 18);

}
